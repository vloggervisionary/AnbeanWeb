# Anbean — kentsel yaşam ve hareket platformu

Kurye/gönderi, yemek siparişi, elektrikli araç kiralama ve sürücülü yolculuk (pilot) modüllerini
tek hesap, tek bakiye ve tek durum şeridi altında toplayan Next.js + PostgreSQL uygulaması.

> Marka adı tek kaynaktan gelir: `src/lib/brand.ts`. Metinler `src/lib/content.ts`,
> yasal belgeler `src/lib/policies.ts` içinde tutulur; bileşenlere hard-code edilmez.

## 1. Gereksinimler

- Node.js 20+
- PostgreSQL 14+
- npm

## 2. Kurulum

```bash
npm install
cp .env.example .env          # DATABASE_URL ve SESSION_SECRET doldur
npx drizzle-kit push          # şemayı uygula (additive, yıkıcı değil)
psql "$DATABASE_URL" -f drizzle/seed.sql        # çekirdek demo verisi
psql "$DATABASE_URL" -f drizzle/seed-food.sql   # pilot yemek kataloğu
psql "$DATABASE_URL" -f drizzle/seed-hail.sql   # sürücülü yolculuk pilot verisi
psql "$DATABASE_URL" -f drizzle/seed-admin.sql  # planlar, CV, blog, şablonlar
npm run build && npm start    # veya: npm run dev
```

### Ortam değişkenleri

| Değişken | Zorunlu | Açıklama |
|---|---|---|
| `DATABASE_URL` | evet | PostgreSQL bağlantısı |
| `SESSION_SECRET` | üretimde evet | Oturum çerezi HMAC anahtarı |
| `CHAUFFEUR_SERVICE_LIVE` | hayır | `true` ise sürücülü yolculuk canlı açılır. **Varsayılan false**: hukuk onayı olmadan gerçek sürücü çevrimiçi olamaz |
| `ALLOW_PRIVATE_CAR_MATCHING` | hayır | `true` ise özel araç (TAG benzeri) eşleştirmesi açılır. Varsayılan kapalı |
| `PEXELS_API_KEY` | hayır | Boşsa `media_slots`'taki sabit URL'ler kullanılır |
| `IYZICO_*`, `SMTP_URL`, `MAPBOX_TOKEN` | hayır | Bağlı değil; ilgili akışlar demo/simülasyon olarak işaretlidir |

## 3. Demo hesaplar

Tümünün erişim kodu `1234` (geçici demo yolu). Yeni kayıt olan kullanıcılarda şifre **scrypt** ile hash'lenir.

| E-posta | Rol | Panel |
|---|---|---|
| `musteri@anbean.com.tr` | Müşteri | `/app` |
| `isletme@anbean.com.tr` | İşletme sahibi | `/isletme` |
| `personel@anbean.com.tr` | İşletme çalışanı | `/isletme` |
| `kurye@anbean.com.tr` | Kurye | `/courier` |
| `surucu@anbean.com.tr` | Sürücü | `/surucu` |
| `ops@anbean.com.tr` | Operasyon | `/ops` |
| `finans@anbean.com.tr` | Finans | `/admin/finans` |
| `destek@anbean.com.tr` | Destek | `/admin/destek` |
| `guvenlik@anbean.com.tr` | Güvenlik | `/ops/guvenlik-olaylari` |
| `editor@anbean.com.tr` | İçerik editörü | `/admin/cms` |
| `admin@anbean.com.tr` | Yönetici | `/admin` |
| `sahip@anbean.com.tr` | Platform yöneticisi | `/admin` |

## 4. Mimari

- **Next.js App Router + TypeScript**, sunucu bileşenleri öncelikli
- **Drizzle ORM + PostgreSQL** (59 tablo, tamamı additive migration)
- **Motion** (animasyon), **lucide-react** (ikon), **zod** (doğrulama), **Fontsource** (kendi sunucumuzdan font)
- Oturum: HMAC imzalı httpOnly çerez (NextAuth yok — Prisma gerektiriyordu)
- Şifre: `node:crypto` scrypt; MFA: TOTP (RFC 6238), bağımlılıksız
- Para: tüm alanlar **kuruş (integer)**; çift taraflı ledger; append-only (DB trigger)

### Yetki modeli

Rotalarda rol adı değil **izin adı** sorulur (`requirePermission("member:manage")`).
12 rol × 72 izin matrisi: `src/lib/permissions.ts`. Tenant izolasyonu sorgu
seviyesinde uygulanır (`orgId` / `createdByUserId`); "tümünü listele" yedeği yoktur.

### Yayın öncesi denetim

```bash
bash scripts/pre-release-check.sh
```

Tarananlar: yer tutucu (`[MARKA ADI]`), lorem, CJK sızıntısı, rakip marka adı, uydurma
metrik kalıbı, TODO/FIXME, token baypası eden sabit hex, gerçek dışı hız vaadi, e-para
iddiası, alt metinsiz `<img>`, arayüzde emoji, taslak olmayan yasal belge.

## 5. Modüller ve durumları

| Modül | Durum | Not |
|---|---|---|
| Gönder (kurye) | çalışıyor | Sunucu taraflı fiyat, durum makinesi, takip, Teslimat Güvencesi |
| Yemek | **pilot** | Katalog demo; sahte puan/yorum yok; ödeme sağlayıcısı bağlı değil |
| Kiralık (mikro-mobilite) | çalışıyor | IoT kilidi simüle; dakika bazlı ücret |
| Sürücülü yolculuk | **pilot, kapı kapalı** | `CHAUFFEUR_SERVICE_LIVE=false`; hukuk onayı bekliyor |
| Yönetim paneli | çalışıyor | Üyeler, CV, işletmeler, SaaS, CMS, finans, destek, ayarlar |

## 6. Bilinen sınırlar (dürüst liste)

- **Veritabanı seviyesinde RLS yok.** İzolasyon uygulama katmanında ve test edildi; SQL'e başka yoldan erişen biri bu kontrolleri atlar.
- **Dosya depolama yok.** Belge/fotoğraf yüklenemez; CV fotoğrafı ve sürücü belgeleri yalnızca meta veri. Onay akışı meta veri üzerinden çalışır.
- **Ödeme/SMS/e-posta sağlayıcısı yok.** Bakiye simülasyondur ve **elektronik para değildir**; OTP ekranda gösterilir.
- **Haritalar şematik SVG.** Mapbox/Leaflet bağlı değil; konum ilçe seviyesinde.
- **Zamanlanmış CMS yayını** alanı saklanır ama zamanlayıcı görev yoktur.
- **Hız sınırı bellek içi**; çok örneklemli dağıtımda çalışmaz.
- **Lighthouse ölçülmedi** (sandbox'ta Chrome yok). İstemci JS gzip ölçümü yapılır.
- Demo erişim kodları (`1234`) üretimden önce kaldırılmalı.
- Test verileri append-only kayıtlar oluşturduğu için geri alınamaz.

## 7. Hukuk onayı bekleyen konular

1. Platform bakiyesi modeli — 6493 sayılı Kanun kapsamında elektronik para sayılır mı?
2. Ticari yolcu taşımacılığı belge rejimi ve özel araç (TAG benzeri) modelinin statüsü
3. IYS (İleti Yönetim Sistemi) yükümlülüğü
4. İş ortağı (restoran/filo) sözleşmeleri
5. Sürücü çalışma modelinin vergi ve sosyal güvenlik statüsü

Tüm yasal belgeler `src/lib/policies.ts` içinde **taslak** olarak işaretlidir ve arayüzde
"Taslak — hukuk danışmanı onayı gereklidir" uyarısıyla gösterilir.
