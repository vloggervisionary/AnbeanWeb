-- Yönetim paneli demo verisi. Gerçek kişisel veri YOK; tümü sahte.
INSERT INTO users (email, full_name, phone, role, passcode) VALUES
  ('editor@anbean.com.tr','Deniz Aklar','05321000010','editor','1234'),
  ('isletme@anbean.com.tr','Moda Butik Yetkilisi','05321000011','isletme_sahibi','1234'),
  ('personel@anbean.com.tr','Moda Butik Personeli','05321000012','isletme_calisani','1234'),
  ('sahip@anbean.com.tr','Platform Sahibi','05321000013','super_admin','1234')
ON CONFLICT (email) DO NOTHING;

INSERT INTO plans (code, name, monthly_kurus, shipment_limit, seat_limit, courier_limit, features) VALUES
  ('baslangic','Başlangıç',99000,200,2,0,'["Panel","Takip","E-posta destek"]'),
  ('buyume','Büyüme',499000,2000,10,5,'["Panel","Takip","API","Webhook","Öncelikli destek"]'),
  ('kurumsal','Kurumsal',1999000,20000,50,25,'["Panel","API","Özel tarife","SLA raporu","Hesap yöneticisi"]')
ON CONFLICT (code) DO NOTHING;

-- İşletme dosyası alanları
UPDATE organizations SET category='Perakende', description='Moda semtinde butik giyim. Aynı gün teslimat için Anbean kullanıyor.',
  contact_email='info@modabutik.example', contact_phone='02160000000', city='İstanbul', district='Kadıköy',
  working_hours='{"pazartesi":"09:00-19:00","sali":"09:00-19:00","cumartesi":"10:00-18:00"}'::jsonb,
  verification_status='dogrulandi' WHERE slug='moda-butik' AND category='';
UPDATE organizations SET category='Teknoloji', description='Kurumsal gönderi hacmi olan teknoloji şirketi.',
  contact_email='lojistik@kadikoytech.example', city='İstanbul', district='Şişli', verification_status='incelemede'
  WHERE slug='kadikoy-teknoloji' AND category='';

INSERT INTO subscriptions (org_id, plan_id, status, trial_ends_at, current_period_end)
SELECT o.id, p.id, 'aktif', now() + interval '14 days', now() + interval '30 days'
FROM organizations o JOIN plans p ON p.code='buyume' WHERE o.slug='moda-butik'
  AND NOT EXISTS (SELECT 1 FROM subscriptions s WHERE s.org_id=o.id);
INSERT INTO subscriptions (org_id, plan_id, status, trial_ends_at, current_period_end)
SELECT o.id, p.id, 'deneme', now() + interval '7 days', NULL
FROM organizations o JOIN plans p ON p.code='kurumsal' WHERE o.slug='kadikoy-teknoloji'
  AND NOT EXISTS (SELECT 1 FROM subscriptions s WHERE s.org_id=o.id);

INSERT INTO invoices (number, org_id, subscription_id, amount_kurus, tax_kurus, total_kurus, status, due_date, provider_ref, note)
SELECT 'FTR-2026-000001', o.id, s.id, 499000, 99800, 598800, 'gonderildi', now() + interval '7 days', '', 'Ödeme sağlayıcısı bağlı değil; tahsilat simülasyondur.'
FROM organizations o JOIN subscriptions s ON s.org_id=o.id WHERE o.slug='moda-butik'
  AND NOT EXISTS (SELECT 1 FROM invoices i WHERE i.number='FTR-2026-000001');

INSERT INTO org_members (org_id, user_id, org_role)
SELECT o.id, u.id, CASE WHEN u.email='isletme@anbean.com.tr' THEN 'sahip' ELSE 'calisan' END
FROM organizations o CROSS JOIN users u
WHERE o.slug='moda-butik' AND u.email IN ('isletme@anbean.com.tr','personel@anbean.com.tr','musteri@anbean.com.tr')
ON CONFLICT (org_id, user_id) DO NOTHING;
UPDATE users SET org_id=(SELECT id FROM organizations WHERE slug='moda-butik') WHERE email IN ('isletme@anbean.com.tr','personel@anbean.com.tr') AND org_id IS NULL;

-- Kurye CV (demo, sahte veri)
INSERT INTO courier_cv (courier_id, display_name, about, default_visibility, availability_note, vehicle_note, profile_published)
SELECT c.id, 'Mert A.', 'Kadıköy ve çevresinde 4 yıldır şehir içi kuryelik. Yoğun saatlerde ekspres gönderilerde deneyimliyim.',
       'personele_acik', 'Hafta içi 10:00-20:00, cumartesi esnek', 'Motosiklet, 250 cc, kapalı kasa', true
FROM couriers c WHERE c.full_name='Mert Aksoy'
  AND NOT EXISTS (SELECT 1 FROM courier_cv cv WHERE cv.courier_id=c.id);

INSERT INTO courier_cv_items (cv_id, kind, title, org, starts_at, ends_at, description, visibility, sort_index)
SELECT cv.id, v.kind, v.title, v.org, v.starts_at, v.ends_at, v.description, v.visibility, v.sort_index
FROM courier_cv cv
CROSS JOIN (VALUES
  ('experience','Şehir içi kurye','Örnek Lojistik A.Ş.','2022','2025','Günde ortalama 25 gönderi, ekspres ve planlı teslimat.','personele_acik',1),
  ('experience','Depo saha elemanı','Örnek Dağıtım','2020','2022','Barkodlu alım ve sevkiyat hazırlığı.','personele_acik',2),
  ('education','Lise','Örnek Anadolu Lisesi','2016','2020','','gizli',3),
  ('skill','Rota planlama','','','','Şehir içi optimal rota.','herkse_acik',4),
  ('skill','Müşteri iletişimi','','','','Teslim anında profesyonel iletişim.','herkse_acik',5),
  ('certification','A2 ehliyet','','2019','2029','Motosiklet sınıfı.','personele_acik',6),
  ('certification','SRC 2 belgesi','','2021','2026','Yolcu/yük taşıma yeterlilik.','personele_acik',7),
  ('language','Türkçe','','','','Ana dil','herkse_acik',8),
  ('language','İngilizce','','','','B1 — teslimatta temel iletişim','herkse_acik',9),
  ('service_area','Kadıköy','','','','Ana hizmet bölgesi','herkse_acik',10),
  ('service_area','Üsküdar','','','','İkincil bölge','herkse_acik',11)
) AS v(kind, title, org, starts_at, ends_at, description, visibility, sort_index)
WHERE cv.display_name='Mert A.'
  AND NOT EXISTS (SELECT 1 FROM courier_cv_items i WHERE i.cv_id=cv.id AND i.title=v.title AND i.kind=v.kind);

-- CMS: blog ve şablonlar
INSERT INTO blog_posts (slug, title, excerpt, body, category, tags, status, published_at, author_id, meta_title, meta_description)
SELECT v.slug, v.title, v.excerpt, v.body, v.category, v.tags::jsonb, 'yayinda', now(), (SELECT id FROM users WHERE email='editor@anbean.com.tr'), v.title, v.excerpt
FROM (VALUES
  ('durum-renk-seridi','Durum Renk Şeridi nasıl okunur?','Altı segment, tek bakışta gönderi durumu.','Her gönderi yatay bir renk şeridiyle temsil edilir. Dolu segmentler tamamlanan aşamaları, soluk segmentler kalan yolu gösterir. Kırmızı segment istisna, mor segment iade sürecidir.','tasarim','["takip","tasarim"]'),
  ('istisna-kuyrugu','İstisna kuyruğu: başarısız teslimatın anatomisi','Beş dakikalık çözüm taahhüdü nasıl işliyor?','Başarısız teslimat istisna kuyruğuna düşer. Operasyon beş dakika içinde yeniden planlama, iade veya inceleme kararı verir; karar denetim kaydına yazılır.','operasyon','["istisna","operasyon"]'),
  ('tek-cuzdan','Tek bakiye: sipariş, gönderi ve sürüş','Üç hizmet aynı bakiyeden ödeniyor.','Sipariş, kurye gönderisi ve elektrikli araç kiralama ücretleri aynı platform bakiyesinden düşer. Her hareket çift taraflı kayıtla yazılır ve silinemez.','urun','["cuzdan","ledger"]')
) AS v(slug,title,excerpt,body,category,tags)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO email_templates (key, name, channel, subject, body) VALUES
  ('durum_teslim_edildi','Teslim edildi bildirimi','email','Gönderin teslim edildi','{{code}} numaralı gönderin {{district}} ilçesinde teslim edildi.'),
  ('durum_istisna','İstisna bildirimi','email','Gönderinle ilgileniyoruz','{{code}} numaralı gönderinde istisna oluştu. Çözüm taahhüdümüz 5 dakika.'),
  ('surus_basladi','Sürüş başladı','sms','—','Sürüşün başladı. Güvenli sürüşler.'),
  ('hakedis_odendi','Hakediş ödemesi','email','Hakedişin ödendi','{{amount}} tutarındaki hakedişin banka çıkışına alındı.')
ON CONFLICT (key) DO NOTHING;

INSERT INTO platform_settings (key, value, updated_by) VALUES
  ('platform', '{"support_phone":"0850 000 00 00","support_email":"destek@anbean.com.tr","default_city":"İstanbul"}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr')),
  ('limits', '{"max_shipment_weight_grams":50000,"max_ride_distance_km":200,"payout_min_kurus":10000}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr')),
  ('veri_saklama', '{"location_ttl_days":30,"audit_retention_years":10,"cv_media_retention":"saglayici_secilmedi"}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr'))
ON CONFLICT (key) DO NOTHING;

-- CMS sayfalarına sürüm geçmişi (mevcut kayıtlar için v1)
INSERT INTO cms_versions (page_id, version, title, body, status, author_id, change_note)
SELECT p.id, 1, p.title, p.body, p.status, (SELECT id FROM users WHERE email='editor@anbean.com.tr'), 'İlk sürüm (geçmiş kayıtlardan oluşturuldu)'
FROM cms_pages p WHERE NOT EXISTS (SELECT 1 FROM cms_versions v WHERE v.page_id=p.id);
