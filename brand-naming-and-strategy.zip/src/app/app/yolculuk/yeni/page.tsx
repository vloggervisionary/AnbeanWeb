import { redirect } from "next/navigation";
import PageShell from "@/components/PageShell";
import HailRequestForm from "@/components/HailRequestForm";
import { getSessionUser } from "@/lib/auth";
import { CHAUFFEUR_SERVICE_GATE } from "@/lib/hail";

export const dynamic = "force-dynamic";
export const metadata = { title: "Yolculuk talep et — Anbean" };

export default async function YeniYolculukPage() {
  const user = await getSessionUser();
  if (!user) redirect("/giris");

  return (
    <PageShell
      eyebrow={`Sürücülü yolculuk · ${CHAUFFEUR_SERVICE_GATE.label}`}
      title="Nereden nereye gidiyorsun?"
      lead="Tahmini ücret sunucudan gelir. Kesin tutar yolculuk sonunda gerçek mesafe ve süreyle hesaplanır; fark sana gösterilir."
    >
      <HailRequestForm loggedIn />
    </PageShell>
  );
}
