import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { trustedContacts } from "@/db/schema";
import { requireAuth } from "@/lib/auth";
import PanelShell, { Card } from "@/components/PanelShell";
import TrustedContactsManager, { type TrustedContact } from "@/components/TrustedContactsManager";

export const dynamic = "force-dynamic";
export const metadata = { title: "Güvenilen kişiler — Anbean" };

export default async function GuvenilenKisilerPage() {
  const user = await requireAuth();
  if (!user) redirect("/giris");

  const rows = await db
    .select({
      id: trustedContacts.id,
      name: trustedContacts.name,
      phoneMasked: trustedContacts.phoneMasked,
      createdAt: trustedContacts.createdAt,
    })
    .from(trustedContacts)
    .where(eq(trustedContacts.userId, user.id))
    .orderBy(desc(trustedContacts.createdAt));

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Güvenilen kişiler"
      subtitle="Yolculuğunu canlı paylaşabileceğin kişiler. Paylaşılan bağlantıda telefonun ve tam adresin görünmez."
      nav={[
        { href: "/app/yolculuk", label: "Yolculuklarım" },
        { href: "/app/guvenilen-kisiler", label: "Güvenilen kişiler" },
        { href: "/hesap/izinler", label: "İzinler" },
      ]}
    >
      <div className="grid gap-5 lg:grid-cols-[1fr_0.7fr]">
        <TrustedContactsManager contacts={rows as TrustedContact[]} />
        <Card title="Paylaşımda ne görünür?">
          <ul className="space-y-2 text-sm text-slate-600">
            <li>· Araç plakası, markası ve rengi</li>
            <li>· Sürücünün adı (soyadı verilmez)</li>
            <li>· Yaklaşık konum (~500 m yuvarlanmış)</li>
            <li>· İlçe seviyesinde rota</li>
            <li>· Acil durum yönlendirmesi (112)</li>
          </ul>
          <p className="mt-4 border-t border-slate-100 pt-4 text-sm text-slate-600">
            <strong className="text-[#0B1220]">Paylaşılmaz:</strong> telefonun, tam adresin, ücret ve ödeme bilgisi.
          </p>
          <p className="mt-3 text-[11px] text-slate-500">
            Bağlantı süreli ve hız sınırlıdır; yolculuk bittiğinde otomatik kapanır.
          </p>
        </Card>
      </div>
    </PanelShell>
  );
}
