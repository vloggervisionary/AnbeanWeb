import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLog,
  chauffeurProfiles,
  cmsPages,
  couriers,
  invoices,
  iotVehicles,
  ledgerEntries,
  organizations,
  passengerRides,
  payoutRequests,
  safetyIncidents,
  shipments,
  supportTickets,
  users,
} from "@/db/schema";
import { requireAuth } from "@/lib/auth";
import { hasPermission, ROLE_PERMISSIONS } from "@/lib/permissions";
import { formatTry } from "@/lib/pricing";
import { STATUS_COLOR } from "@/lib/status";
import { nowMillis } from "@/lib/clock";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import { ADMIN_NAV } from "./uyeler/page";

export const dynamic = "force-dynamic";
export const metadata = { title: "Yönetim özeti — Anbean" };

const TERMINAL = ["teslim_edildi", "iade_edildi", "iptal", "arsivlendi"];

export default async function AdminPanel() {
  const user = await requireAuth();
  if (!user) redirect("/giris");
  if (!hasPermission(user.role, "member:read") && user.role !== "admin" && user.role !== "super_admin" && user.role !== "ops") {
    redirect("/giris");
  }

  const now = nowMillis();
  const [
    userRows,
    courierRows,
    orgRows,
    shipmentRows,
    rideRows,
    hailRows,
    vehicleRows,
    ticketRows,
    incidentRows,
    payoutRows,
    invoiceRows,
    ledgerRows,
    pageRows,
    logRows,
    chauffeurRows,
  ] = await Promise.all([
    db.select().from(users),
    db.select().from(couriers),
    db.select().from(organizations),
    db.select().from(shipments),
    db.select().from(passengerRides),
    db.select().from(passengerRides),
    db.select().from(iotVehicles),
    db.select().from(supportTickets),
    db.select().from(safetyIncidents),
    db.select().from(payoutRequests),
    db.select().from(invoices),
    db.select().from(ledgerEntries).orderBy(desc(ledgerEntries.createdAt)).limit(50),
    db.select().from(cmsPages),
    db.select().from(auditLog).orderBy(desc(auditLog.createdAt)).limit(15),
    db.select().from(chauffeurProfiles),
  ]);
  void rideRows;

  const revenue = shipmentRows.reduce((sum, row) => sum + row.priceKurus, 0);
  const delivered = shipmentRows.filter((r) => r.status === "teslim_edildi").length;
  const activeMembers = userRows.filter((u) => u.isActive && !u.isBanned && u.archivedAt === null).length;
  const pendingMembers = userRows.filter((u) => u.kvkkConsentAt === null);
  const suspended = userRows.filter((u) => u.isBanned).length;

  const openShipments = shipmentRows.filter((r) => !TERMINAL.includes(r.status));
  const lateShipments = openShipments.filter((r) => r.etaAt !== null && new Date(r.etaAt).getTime() < now);
  const unassigned = openShipments.filter((r) => r.status === "kurye_atamasi_bekliyor");

  const openTickets = ticketRows.filter((t) => t.status === "acik" || t.status === "isleniyor");
  const openIncidents = incidentRows.filter((i) => i.status === "open" || i.status === "assigned");
  const pendingPayouts = payoutRows.filter((p) => p.status === "beklemede" || p.status === "onaylandi");
  const overdueInvoices = invoiceRows.filter(
    (i) => i.status === "gonderildi" && i.dueDate !== null && new Date(i.dueDate).getTime() < now,
  );
  const lowBattery = vehicleRows.filter((v) => v.batteryPercent < 20);
  const unverifiedDrivers = chauffeurRows.filter((c) => !c.commercialDocsVerified);
  const draftPages = pageRows.filter((p) => p.status === "taslak" || p.status === "incelemede");

  const totalDebit = ledgerRows.filter((r) => r.side === "debit").reduce((s, r) => s + r.amountKurus, 0);
  const totalCredit = ledgerRows.filter((r) => r.side === "credit").reduce((s, r) => s + r.amountKurus, 0);

  /** Bekleyen işler: her kart doğrudan ilgili kayda gider. */
  const queue = [
    { label: "SLA'sı geçen gönderi", count: lateShipments.length, href: "/ops/uyarilar", tone: STATUS_COLOR.risk, permission: "report:read" },
    { label: "Kurye bekleyen gönderi", count: unassigned.length, href: "/ops", tone: STATUS_COLOR.waiting, permission: "shipment:assign" },
    { label: "Açık destek talebi", count: openTickets.length, href: "/admin/destek", tone: STATUS_COLOR.transit, permission: "support:manage" },
    { label: "Güvenlik olayı", count: openIncidents.length, href: "/ops/guvenlik-olaylari", tone: STATUS_COLOR.risk, permission: "safety:read" },
    { label: "Hakediş onayı bekliyor", count: pendingPayouts.length, href: "/admin/finans", tone: STATUS_COLOR.waiting, permission: "finance:payout" },
    { label: "Vadesi geçen fatura", count: overdueInvoices.length, href: "/admin/isletmeler", tone: STATUS_COLOR.risk, permission: "invoice:read" },
    { label: "Düşük bataryalı araç", count: lowBattery.length, href: "/ops", tone: STATUS_COLOR.waiting, permission: "vehicle:manage" },
    { label: "Belgesi eksik sürücü", count: unverifiedDrivers.length, href: "/admin/suruculer", tone: STATUS_COLOR.waiting, permission: "chauffeur:verify" },
    { label: "Doğrulanmamış üye", count: pendingMembers.length, href: "/admin/uyeler", tone: STATUS_COLOR.neutral, permission: "member:read" },
    { label: "Yayın bekleyen içerik", count: draftPages.length, href: "/admin/cms", tone: STATUS_COLOR.neutral, permission: "cms:read" },
  ].filter((item) => hasPermission(user.role, item.permission as never) || user.role === "admin" || user.role === "super_admin");

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Yönetim özeti"
      subtitle={`İzin sayın: ${ROLE_PERMISSIONS[user.role]?.length ?? 0} · kartlar yalnızca yetkine göre görünür`}
      nav={ADMIN_NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Üye" value={`${activeMembers} aktif / ${userRows.length} toplam`} />
        <Metric label="Kurye" value={String(courierRows.length)} tone={STATUS_COLOR.transit} />
        <Metric label="İşletme" value={String(orgRows.length)} />
        <Metric label="Sürücü (pilot)" value={String(chauffeurRows.length)} tone={STATUS_COLOR.waiting} />
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-4">
        <Metric label="Gönderi" value={`${openShipments.length} açık / ${delivered} teslim`} />
        <Metric label="Ciro (kayıtlı)" value={formatTry(revenue)} tone="var(--gonder)" />
        <Metric label="Elektrikli araç" value={`${vehicleRows.filter((v) => v.status === "available").length} hazır`} tone={STATUS_COLOR.delivered} />
        <Metric label="Ledger (son 50)" value={`${formatTry(totalDebit)} / ${formatTry(totalCredit)}`} />
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
        <Card title="Bekleyen işler">
          <ul className="grid gap-2 sm:grid-cols-2">
            {queue.map((item) => (
              <li key={item.label}>
                <Link
                  href={item.href}
                  className="flex items-center justify-between gap-3 rounded-md border border-slate-200 p-3 transition hover:border-slate-400 hover:bg-slate-50"
                >
                  <span className="text-sm text-slate-700">{item.label}</span>
                  <span
                    className="rounded-full px-2.5 py-1 text-xs font-bold tabular-nums"
                    style={{ color: item.tone, backgroundColor: `${item.tone}1f` }}
                  >
                    {item.count}
                  </span>
                </Link>
              </li>
            ))}
            {queue.length === 0 ? <li className="text-sm text-slate-500">Yetkine giren bekleyen iş yok.</li> : null}
          </ul>
        </Card>

        <Card title="Son denetim kayıtları">
          <ul className="max-h-80 divide-y divide-slate-100 overflow-auto text-sm">
            {logRows.map((log) => (
              <li key={log.id} className="py-2">
                <p className="font-medium text-slate-800">{log.action}</p>
                <p className="text-xs text-slate-500">
                  {log.actorRole} · {log.entity}
                  {log.entityId ? `#${log.entityId}` : ""} · {new Date(log.createdAt).toLocaleString("tr-TR")}
                </p>
                {log.reason ? <p className="text-[11px] text-slate-500">gerekçe: {log.reason}</p> : null}
              </li>
            ))}
          </ul>
          <Link href="/admin/ayarlar" className="mt-3 inline-block text-xs font-semibold text-accent">
            Ayarlar ve MFA →
          </Link>
        </Card>
      </div>

      <p className="mt-6 text-xs text-slate-500">
        Veri kaynağı: {shipmentRows.length} gönderi, {hailRows.length} sürücülü yolculuk, {ledgerRows.length} son ledger
        kaydı. Sayılar canlı sorgudan gelir; grafik yerine sayaç kullanıldı çünkü dönem serisi henüz yeterli değil
        (uydurma trend çizilmedi).
      </p>
    </PanelShell>
  );
}

