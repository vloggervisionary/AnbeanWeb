import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, isNull } from "drizzle-orm";
import { db } from "@/db";
import { organizations, subscriptions, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import PanelShell, { Metric } from "@/components/PanelShell";
import { ADMIN_NAV } from "../uyeler/page";

export const dynamic = "force-dynamic";
export const metadata = { title: "İşletmeler — Anbean Yönetim" };

const VERIFICATION_LABEL: Record<string, string> = {
  dogrulanmadi: "Doğrulanmadı",
  incelemede: "İncelemede",
  dogrulandi: "Doğrulandı",
  reddedildi: "Reddedildi",
};

export default async function IsletmelerPage() {
  const user = await requirePermission("org:read");
  if (!user) redirect("/giris");

  const scoped = user.role === "isletme_sahibi" || user.role === "isletme_calisani";
  const allOrgs = await db.select().from(organizations).where(isNull(organizations.archivedAt)).orderBy(desc(organizations.createdAt));
  const orgs = scoped ? allOrgs.filter((org) => org.id === user.orgId) : allOrgs;

  const [subs, memberCounts] = await Promise.all([
    db.select().from(subscriptions),
    db.select({ orgId: users.orgId }).from(users),
  ]);
  const countByOrg = new Map<number, number>();
  for (const row of memberCounts) {
    if (row.orgId === null) continue;
    countByOrg.set(row.orgId, (countByOrg.get(row.orgId) ?? 0) + 1);
  }

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="İşletmeler"
      subtitle={scoped ? "Yalnızca kendi işletmen listelenir." : "Tenant kayıtları, abonelikler ve doğrulama durumları."}
      nav={ADMIN_NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="İşletme" value={String(orgs.length)} />
        <Metric label="Doğrulandı" value={String(orgs.filter((o) => o.verificationStatus === "dogrulandi").length)} tone="#16A34A" />
        <Metric label="İncelemede" value={String(orgs.filter((o) => o.verificationStatus === "incelemede").length)} tone="#F59E0B" />
        <Metric label="Aktif abonelik" value={String(subs.filter((s) => s.status === "aktif").length)} tone="#2563EB" />
      </div>

      <div className="mt-6 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-[11px] uppercase tracking-[0.08em] text-slate-500">
            <tr>
              <th className="px-4 py-3">İşletme</th>
              <th className="px-4 py-3">Tür</th>
              <th className="px-4 py-3">Üye</th>
              <th className="px-4 py-3">Abonelik</th>
              <th className="px-4 py-3">Doğrulama</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {orgs.map((org) => {
              const sub = subs.find((s) => s.orgId === org.id);
              return (
                <tr key={org.id} className="transition hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <Link href={`/admin/isletmeler/${org.id}`} className="font-medium text-[#0B1220] hover:text-accent">
                      {org.name}
                    </Link>
                    <p className="text-xs text-slate-500">
                      {org.city} {org.district ? `· ${org.district}` : ""} {org.category ? `· ${org.category}` : ""}
                    </p>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{org.type}</td>
                  <td className="px-4 py-3 text-slate-600">{countByOrg.get(org.id) ?? 0}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] text-slate-600">{sub?.status ?? "yok"}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{
                        color: org.verificationStatus === "dogrulandi" ? "#15803d" : org.verificationStatus === "reddedildi" ? "#B91C1C" : "#B45309",
                        backgroundColor:
                          org.verificationStatus === "dogrulandi" ? "#dcfce7" : org.verificationStatus === "reddedildi" ? "#fee2e2" : "#fef3c7",
                      }}
                    >
                      {VERIFICATION_LABEL[org.verificationStatus] ?? org.verificationStatus}
                    </span>
                  </td>
                </tr>
              );
            })}
            {orgs.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-slate-500">
                  İşletme kaydı yok.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      <p className="mt-4 text-xs text-slate-500">
        Yeni işletme açma API üzerinden: <code>POST /api/admin/orgs</code> (org:manage). Arayüzde henüz form yok —
        işlevsiz buton bırakmamak için eklenmedi.
      </p>
    </PanelShell>
  );
}
