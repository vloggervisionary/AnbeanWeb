import { z } from "zod";
import { db } from "@/db";
import { chauffeurOffers, chauffeurProfiles, chauffeurVehicles, passengerRides } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { logRideEvent } from "@/lib/hail";
import { issuePickupOtp } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({ decision: z.enum(["accept", "decline"]) });

/** Sürücü teklifi kabul/red. Süresi dolan teklif kabul edilemez. */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:offer");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz teklif" }, { status: 400 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz karar" }, { status: 400 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü profili bulunamadı" }, { status: 403 });

  const [offer] = await db
    .select()
    .from(chauffeurOffers)
    .where(and(eq(chauffeurOffers.id, id), eq(chauffeurOffers.chauffeurId, profile.id)))
    .limit(1);
  if (!offer) return Response.json({ error: "Teklif bulunamadı" }, { status: 404 });

  if (offer.expiresAt.getTime() < Date.now()) {
    await db.update(chauffeurOffers).set({ status: "expired" }).where(eq(chauffeurOffers.id, id));
    return Response.json({ error: "Teklif süresi doldu." }, { status: 410 });
  }
  if (offer.status !== "sent") {
    return Response.json({ error: `Teklif zaten ${offer.status}.` }, { status: 409 });
  }
  if (!profile.isVerified || !profile.commercialDocsVerified) {
    return Response.json({ error: "Ticari yolcu taşıma belgeleriniz doğrulanmadan teklif kabul edemezsiniz." }, { status: 403 });
  }
  if (profile.availability !== "online_idle") {
    return Response.json({ error: "Yalnızca çevrimiçi ve boştayken teklif kabul edilebilir." }, { status: 409 });
  }

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, offer.rideId)).limit(1);
  if (!ride || ride.status !== "MATCHING") {
    await db.update(chauffeurOffers).set({ status: "expired", respondedAt: new Date() }).where(eq(chauffeurOffers.id, id));
    return Response.json({ error: "Bu yolculuk artık eşleşmiyor." }, { status: 409 });
  }

  if (parsed.data.decision === "decline") {
    await db
      .update(chauffeurOffers)
      .set({ status: "declined", respondedAt: new Date() })
      .where(eq(chauffeurOffers.id, id));
    await db
      .update(chauffeurProfiles)
      .set({ declinedOffers: sql`${chauffeurProfiles.declinedOffers} + 1` })
      .where(eq(chauffeurProfiles.id, profile.id));
    await logRideEvent({ rideId: ride.id, eventType: "OFFER_DECLINED", actor: "chauffeur" });
    return Response.json({ ok: true, status: "declined" });
  }

  // Kabul: diğer teklifler düşer, sürücü atanır, buluşma kodu üretilir.
  const [vehicle] = await db
    .select()
    .from(chauffeurVehicles)
    .where(and(eq(chauffeurVehicles.chauffeurId, profile.id), eq(chauffeurVehicles.isActive, true)))
    .limit(1);
  if (!vehicle) return Response.json({ error: "Aktif aracınız kayıtlı değil." }, { status: 409 });

  await db.update(chauffeurOffers).set({ status: "declined", respondedAt: new Date() }).where(
    and(eq(chauffeurOffers.rideId, ride.id), sql`${chauffeurOffers.id} <> ${id}`, eq(chauffeurOffers.status, "sent")),
  );
  await db.update(chauffeurOffers).set({ status: "accepted", respondedAt: new Date() }).where(eq(chauffeurOffers.id, id));
  await db
    .update(passengerRides)
    .set({
      status: "DRIVER_ASSIGNED",
      chauffeurId: profile.id,
      vehicleId: vehicle.id,
      matchedAt: new Date(),
    })
    .where(eq(passengerRides.id, ride.id));
  await db
    .update(chauffeurProfiles)
    .set({
      availability: "on_trip",
      acceptedOffers: sql`${chauffeurProfiles.acceptedOffers} + 1`,
    })
    .where(eq(chauffeurProfiles.id, profile.id));

  const otp = await issuePickupOtp(ride.id);
  await logRideEvent({
    rideId: ride.id,
    eventType: "DRIVER_ASSIGNED",
    actor: "chauffeur",
    note: `${profile.fullName.split(" ")[0]} · ${vehicle.plate}`,
  });
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "suruculu_teklif_kabul",
    entity: "passenger_ride",
    entityId: String(ride.id),
    meta: { chauffeurId: profile.id, etaSec: offer.quotedEtaSec },
  });

  return Response.json({
    ok: true,
    status: "DRIVER_ASSIGNED",
    rideId: ride.id,
    etaSec: offer.quotedEtaSec,
    // Demo: SMS sağlayıcısı yok, kod sürücüye gösterilmez; yolcu tarafında görünür.
    otpDeliveredTo: "passenger",
    otpDebug: process.env.CHAUFFEUR_SERVICE_LIVE === "true" ? undefined : otp,
  });
}
