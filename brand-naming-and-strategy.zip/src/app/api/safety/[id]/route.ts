import { z } from "zod";
import { db } from "@/db";
import { safetyIncidents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const schema = z.object({
  action: z.enum(["assign", "resolve", "close"]),
  resolutionNote: z.string().trim().max(300).optional(),
});

/** Olay üstlenme, çözüm ve kapatma. Yalnızca safety:manage yetkisi. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("safety:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz olay" }, { status: 400 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz işlem" }, { status: 400 });

  const [incident] = await db.select().from(safetyIncidents).where(eq(safetyIncidents.id, id)).limit(1);
  if (!incident) return Response.json({ error: "Olay bulunamadı" }, { status: 404 });

  const status = parsed.data.action === "assign" ? "assigned" : parsed.data.action === "resolve" ? "resolved" : "closed";
  await db
    .update(safetyIncidents)
    .set({
      status,
      assignedToUserId: parsed.data.action === "assign" ? user.id : incident.assignedToUserId,
      resolutionNote: parsed.data.resolutionNote ?? incident.resolutionNote,
      resolvedAt: status === "resolved" || status === "closed" ? new Date() : incident.resolvedAt,
    })
    .where(eq(safetyIncidents.id, id));

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: `guvenlik_olayi_${parsed.data.action}`,
    entity: "safety_incident",
    entityId: String(id),
    meta: { status },
  });

  return Response.json({ ok: true, status });
}
