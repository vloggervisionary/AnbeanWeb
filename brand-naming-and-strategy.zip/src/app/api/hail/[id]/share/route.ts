import crypto from "node:crypto";
import { z } from "zod";
import { db } from "@/db";
import { passengerRideRequests, passengerRides, rideShareSessions, trustedContacts } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const schema = z.object({ contactId: z.number().int().positive() });

/**
 * Güvenilen kişiyle canlı paylaşım.
 * Yüksek entropi token, süreli, hız sınırlı. Yolculuk bitince oturum kapanır.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz kişi" }, { status: 400 });

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });
  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  if (!request || request.customerId !== user.id) {
    return Response.json({ error: "Bu yolculuk size ait değil" }, { status: 403 });
  }
  if (["COMPLETED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW"].includes(ride.status)) {
    return Response.json({ error: "Bitmiş yolculuk için paylaşım açılamaz." }, { status: 409 });
  }

  const [contact] = await db
    .select()
    .from(trustedContacts)
    .where(and(eq(trustedContacts.id, parsed.data.contactId), eq(trustedContacts.userId, user.id)))
    .limit(1);
  if (!contact) return Response.json({ error: "Güvenilen kişi bulunamadı" }, { status: 404 });

  const token = crypto.randomBytes(18).toString("base64url");
  const [session] = await db
    .insert(rideShareSessions)
    .values({
      rideId: ride.id,
      contactId: contact.id,
      token,
      // Yolculuk + 45 dk; yolculuk biterse oturum da kapatılır.
      expiresAt: new Date(Date.now() + 45 * 60_000),
    })
    .returning();

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "yolculuk_paylasimi_acildi",
    entity: "passenger_ride",
    entityId: String(ride.id),
    meta: { contactId: contact.id },
  });

  return Response.json({ ok: true, token: session.token, url: `/paylasim/${session.token}` });
}
