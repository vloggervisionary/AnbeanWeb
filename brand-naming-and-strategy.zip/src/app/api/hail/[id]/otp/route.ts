import { db } from "@/db";
import { passengerRideRequests, passengerRides } from "@/db/schema";
import { eq } from "drizzle-orm";
import { headers } from "next/headers";
import { rateLimit, requirePermission, writeAudit } from "@/lib/auth";
import { issuePickupOtp, logRideEvent } from "@/lib/hail";

export const dynamic = "force-dynamic";

/**
 * Buluşma kodu.
 * - Kodu YALNIZCA yolcu üretebilir/görebilir; sürücü doğrular.
 * - Ham kod saklanmaz, yalnızca sha256 özeti.
 * - Brute-force'a karşı sıkı hız sınırı.
 * - Gerçek SMS sağlayıcısı yok: kod yanıtta döner ve sunucu günlüğüne yazılır
 *   (demo olduğu arayüzde açıkça belirtilir).
 */
export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`otp:${user.id}:${ip}`, 5, 10 * 60_000)) {
    return Response.json({ error: "Çok fazla kod istendi. 10 dakika bekleyin." }, { status: 429 });
  }

  const id = Number((await ctx.params).id);
  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });

  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  if (!request || request.customerId !== user.id) {
    return Response.json({ error: "Bu yolculuk size ait değil" }, { status: 403 });
  }
  if (!["DRIVER_ASSIGNED", "DRIVER_EN_ROUTE", "DRIVER_ARRIVED"].includes(ride.status)) {
    return Response.json({ error: "Kod yalnızca sürücü atandıktan sonra üretilir." }, { status: 409 });
  }

  const code = await issuePickupOtp(id);
  await logRideEvent({ rideId: id, eventType: "OTP_ISSUED", actor: "user" });
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "bulusma_kodu_uretildi",
    entity: "passenger_ride",
    entityId: String(id),
    // Kod loglanmaz.
  });

  return Response.json({
    ok: true,
    code,
    demoNotice: "SMS sağlayıcısı bağlı değil; kod burada gösteriliyor. Gerçek dağıtımda yalnızca SMS ile iletilir.",
  });
}
