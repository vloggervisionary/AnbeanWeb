import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, chauffeurTariffs, passengerRideRequests, passengerRides, wallets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { canTransitionRide, logRideEvent } from "@/lib/hail";
import { ensureWallet, postLedger } from "@/lib/ledger";
import { formatTry } from "@/lib/pricing";

export const dynamic = "force-dynamic";

const schema = z.object({
  reason: z.string().trim().max(200).optional(),
});

/**
 * Yolcu iptali. İptal ücreti TARİFEDE tanımlıysa sunucu tarafında uygulanır;
 * istemciden ücret değiştirilemez. Sürücü buluşma noktasına vardıysa ücret doğar.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:cancel");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });

  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  if (!request || request.customerId !== user.id) {
    return Response.json({ error: "Bu yolculuk size ait değil" }, { status: 403 });
  }
  if (!canTransitionRide(ride.status, "CANCELLED_BY_PASSENGER")) {
    return Response.json({ error: "Bu aşamada iptal edilemez." }, { status: 409 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  const reason = parsed.success ? (parsed.data.reason ?? "") : "";

  const [tariff] = await db.select().from(chauffeurTariffs).where(eq(chauffeurTariffs.code, ride.tariffCode)).limit(1);
  // Ücret yalnızca sürücü buluşma noktasına ulaştıysa doğar.
  const cancelFeeKurus = ride.status === "DRIVER_ARRIVED" ? (tariff?.cancelFeeKurus ?? 0) : 0;

  if (cancelFeeKurus > 0 && request.paymentMethod === "bakiye") {
    const wallet = await ensureWallet("user", user.id);
    const [systemWallet] = await db.select().from(wallets).where(eq(wallets.ownerKind, "system")).limit(1);
    if (systemWallet && wallet.balanceKurus >= cancelFeeKurus) {
      try {
        await postLedger({
          kind: "ride_charge",
          idempotencyKey: `hail_${ride.id}_cancel_fee`,
          refKind: "passenger_ride",
          refId: ride.id,
          note: `${ride.code} · iptal ücreti`,
          postings: [
            { walletId: wallet.id, side: "debit", amountKurus: cancelFeeKurus, reason: "iptal_ucreti" },
            { walletId: systemWallet.id, side: "credit", amountKurus: cancelFeeKurus, reason: "iptal_ucreti_geliri" },
          ],
        });
      } catch {
        // Bakiye yetmezse iptal yine yapılır; ücret tahakkuk eder, tahsil edilmez.
      }
    }
  }

  await db
    .update(passengerRides)
    .set({
      status: "CANCELLED_BY_PASSENGER",
      cancelReason: reason,
      cancelFeeKurus,
      paymentStatus: cancelFeeKurus > 0 ? "odendi" : "iptal",
    })
    .where(eq(passengerRides.id, id));

  if (ride.chauffeurId) {
    await db.update(chauffeurProfiles).set({ availability: "online_idle" }).where(eq(chauffeurProfiles.id, ride.chauffeurId));
  }

  await logRideEvent({ rideId: id, eventType: "CANCELLED_BY_PASSENGER", actor: "user", note: reason });
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "suruculu_yolculuk_iptal",
    entity: "passenger_ride",
    entityId: String(id),
    meta: { cancelFeeKurus, atStatus: ride.status },
  });

  return Response.json({
    ok: true,
    cancelFeeKurus,
    message: cancelFeeKurus > 0 ? `İptal ücreti ${formatTry(cancelFeeKurus)} uygulandı.` : "Yolculuk iptal edildi.",
  });
}
