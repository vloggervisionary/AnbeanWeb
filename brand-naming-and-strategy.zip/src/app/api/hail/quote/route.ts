import { headers } from "next/headers";
import { z } from "zod";
import { rateLimit } from "@/lib/auth";
import { calculateFare, CHAUFFEUR_SERVICE_GATE, isNightHours } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({
  distanceKm: z.number().min(0.5).max(200),
  durationMin: z.number().min(1).max(400),
  tariffCode: z.string().trim().max(40).optional(),
  isAirport: z.boolean().optional(),
});

/** Giriş gerektirmeyen fiyat tahmini. Tutar sunucuda hesaplanır. */
export async function POST(req: Request) {
  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`hail-quote:${ip}`, 60, 60_000)) {
    return Response.json({ error: "Çok fazla istek" }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz tahmin isteği" }, { status: 400 });
  }

  const fare = await calculateFare({ ...parsed.data, tariffCode: parsed.data.tariffCode });
  if (!fare) return Response.json({ error: "Tarife bulunamadı" }, { status: 404 });

  return Response.json({
    ...fare,
    nightApplied: isNightHours(),
    // Hizmet canlı değilse tahmin yine gösterilir ama sipariş verilemez.
    serviceLive: CHAUFFEUR_SERVICE_GATE.live,
    serviceLabel: CHAUFFEUR_SERVICE_GATE.label,
    disclaimer:
      "Bu bir tahmindir. Kesin tutar yolculuk sonunda gerçek mesafe ve süreyle sunucuda yeniden hesaplanır; fark size gösterilir.",
  });
}
