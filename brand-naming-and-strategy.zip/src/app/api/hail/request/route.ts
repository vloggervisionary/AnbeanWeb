import { z } from "zod";
import { db } from "@/db";
import { passengerRideRequests, passengerRides, wallets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import {
  calculateFare,
  CHAUFFEUR_SERVICE_GATE,
  findCandidates,
  logRideEvent,
  sendOffers,
} from "@/lib/hail";
import { ensureWallet } from "@/lib/ledger";
import { formatTry } from "@/lib/pricing";

export const dynamic = "force-dynamic";

const schema = z.object({
  pickupDistrict: z.string().trim().min(2).max(60),
  pickupAddress: z.string().trim().min(10, "Alım adresi en az 10 karakter").max(240),
  pickupLat: z.number().min(-90).max(90).optional(),
  pickupLng: z.number().min(-180).max(180).optional(),
  dropDistrict: z.string().trim().min(2).max(60),
  dropAddress: z.string().trim().min(10).max(240),
  dropLat: z.number().min(-90).max(90).optional(),
  dropLng: z.number().min(-180).max(180).optional(),
  distanceKm: z.number().min(0.5).max(200),
  durationMin: z.number().min(1).max(400),
  serviceType: z.enum(["standart", "konfor", "erisilebilir"]).default("standart"),
  paymentMethod: z.enum(["bakiye", "fatura"]).default("bakiye"),
  tariffCode: z.string().trim().max(40).optional(),
  note: z.string().trim().max(200).optional(),
  idempotencyKey: z.string().trim().min(8).max(80),
});

const VEHICLE_FOR_SERVICE: Record<string, string> = {
  standart: "standard",
  konfor: "comfort",
  erisilebilir: "accessible",
};

export async function POST(req: Request) {
  const user = await requirePermission("hail:request");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Talep bilgileri eksik" }, { status: 400 });
  }
  const input = parsed.data;

  // İdempotency: aynı anahtar ikinci yolculuk açmaz.
  const existing = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.idempotencyKey, input.idempotencyKey))
    .limit(1);
  if (existing[0]) {
    const ride = await db
      .select()
      .from(passengerRides)
      .where(eq(passengerRides.requestId, existing[0].id))
      .limit(1);
    return Response.json({ ok: true, duplicate: true, code: ride[0]?.code, rideId: ride[0]?.id });
  }

  // Ücret sunucuda kilitlenir; istemciden tutar alınmaz.
  const fare = await calculateFare({
    distanceKm: input.distanceKm,
    durationMin: input.durationMin,
    tariffCode: input.tariffCode,
  });
  if (!fare) return Response.json({ error: "Tarife bulunamadı" }, { status: 404 });

  if (input.paymentMethod === "bakiye") {
    const wallet = await ensureWallet("user", user.id);
    if (wallet.balanceKurus < fare.totalKurus) {
      return Response.json(
        {
          error: `Bakiye yetersiz: ${formatTry(wallet.balanceKurus)} mevcut, tahmini ${formatTry(fare.totalKurus)} gerekli.`,
          code: "balance_insufficient",
        },
        { status: 402 },
      );
    }
  }

  const seq = String(Date.now()).slice(-6);
  const year = new Date().getFullYear();
  const requestCode = `TLP-${year}-${seq}`;

  const [request] = await db
    .insert(passengerRideRequests)
    .values({
      code: requestCode,
      customerId: user.id,
      pickupDistrict: input.pickupDistrict,
      pickupAddress: input.pickupAddress,
      pickupLat: input.pickupLat ?? null,
      pickupLng: input.pickupLng ?? null,
      dropDistrict: input.dropDistrict,
      dropAddress: input.dropAddress,
      dropLat: input.dropLat ?? null,
      dropLng: input.dropLng ?? null,
      distanceKm: input.distanceKm,
      serviceType: input.serviceType,
      vehicleTypeRequested: VEHICLE_FOR_SERVICE[input.serviceType] ?? "standard",
      paymentMethod: input.paymentMethod,
      tariffCode: fare.tariffCode,
      quotedFareKurus: fare.totalKurus,
      note: input.note ?? "",
      idempotencyKey: input.idempotencyKey,
    })
    .returning();

  const [ride] = await db
    .insert(passengerRides)
    .values({
      code: `YLC-${year}-${seq}`,
      requestId: request.id,
      status: "REQUESTED",
      quotedFareKurus: fare.totalKurus,
      tariffCode: fare.tariffCode,
      distanceKm: input.distanceKm,
      isDemo: !CHAUFFEUR_SERVICE_GATE.live,
    })
    .returning();

  await logRideEvent({
    rideId: ride.id,
    eventType: "REQUESTED",
    actor: "user",
    lat: input.pickupLat ?? null,
    lng: input.pickupLng ?? null,
    note: `${input.pickupDistrict} → ${input.dropDistrict}`,
  });

  // Eşleştirme: yalnızca ticari belgesi doğrulanmış, çevrimiçi sürücüler.
  const candidates = await findCandidates({
    pickupLat: input.pickupLat ?? null,
    pickupLng: input.pickupLng ?? null,
    pickupDistrict: input.pickupDistrict,
    vehicleTypeRequested: VEHICLE_FOR_SERVICE[input.serviceType] ?? "standard",
    accessibleNeeded: input.serviceType === "erisilebilir",
  });

  if (candidates.length === 0) {
    await db.update(passengerRides).set({ status: "DRIVER_NO_SHOW" }).where(eq(passengerRides.id, ride.id));
    await logRideEvent({
      rideId: ride.id,
      eventType: "DRIVER_NO_SHOW",
      note: "Uygun sürücü bulunamadı (çevrimiçi ve belgesi doğrulanmış sürücü yok)",
    });
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "suruculu_talep_eslesmedi",
      entity: "passenger_ride",
      entityId: String(ride.id),
    });
    return Response.json(
      { ok: false, code: ride.code, rideId: ride.id, status: "DRIVER_NO_SHOW", reason: "no_driver" },
      { status: 200 },
    );
  }

  await sendOffers(ride.id, candidates);
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "suruculu_talep_olusturuldu",
    entity: "passenger_ride",
    entityId: String(ride.id),
    meta: { quotedFareKurus: fare.totalKurus, offers: candidates.length },
  });

  const [systemWallet] = await db.select().from(wallets).where(eq(wallets.ownerKind, "system")).limit(1);
  void systemWallet;

  return Response.json({
    ok: true,
    code: ride.code,
    rideId: ride.id,
    status: "MATCHING",
    quotedFareKurus: fare.totalKurus,
    offersSent: candidates.length,
    serviceLive: CHAUFFEUR_SERVICE_GATE.live,
  });
}
