import { db } from "@/db";
import { chauffeurOffers, chauffeurProfiles, passengerRideRequests, passengerRides } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requirePermission } from "@/lib/auth";
import { expireStaleOffers } from "@/lib/hail";

export const dynamic = "force-dynamic";

/** Sürücünün açık teklifleri. Süresi dolanlar okuma anında kapatılır. */
export async function GET() {
  const user = await requirePermission("hail:offer");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json([]);

  const offers = await db
    .select()
    .from(chauffeurOffers)
    .where(and(eq(chauffeurOffers.chauffeurId, profile.id), eq(chauffeurOffers.status, "sent")));

  const result = [];
  for (const offer of offers) {
    await expireStaleOffers(offer.rideId);
    const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, offer.rideId)).limit(1);
    if (!ride || ride.status !== "MATCHING") continue;
    const [request] = await db
      .select()
      .from(passengerRideRequests)
      .where(eq(passengerRideRequests.id, ride.requestId))
      .limit(1);

    result.push({
      id: offer.id,
      rideId: ride.id,
      rideCode: ride.code,
      quotedEtaSec: offer.quotedEtaSec,
      expiresAt: offer.expiresAt,
      status: offer.status,
      pickupDistrict: request?.pickupDistrict ?? "",
      dropDistrict: request?.dropDistrict ?? "",
      // Yolcunun tam adresi teklif aşamasında sürücüye gösterilmez.
      quotedFareKurus: ride.quotedFareKurus,
    });
  }

  return Response.json(result);
}
