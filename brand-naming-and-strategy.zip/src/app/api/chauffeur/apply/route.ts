import { headers } from "next/headers";
import { z } from "zod";
import { db } from "@/db";
import { chauffeurApplications, chauffeurDocuments, chauffeurProfiles, chauffeurVehicles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { rateLimit, requireAuth, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const DOC_TYPES = [
  "identity",
  "driver_license",
  "vehicle_registration",
  "insurance",
  "criminal_record",
  "commercial_license",
] as const;

const schema = z.object({
  fullName: z.string().trim().min(3).max(120),
  phone: z.string().trim().min(10).max(20),
  city: z.string().trim().max(60).default("İstanbul"),
  vehicleType: z.enum(["standard", "comfort", "accessible", "van"]).default("standard"),
  ownership: z.enum(["private", "platform"]).default("private"),
  hasCommercialLicense: z.boolean().default(false),
  experienceYears: z.number().int().min(0).max(60).default(0),
  note: z.string().trim().max(500).optional(),
  plate: z.string().trim().max(20).optional(),
});

function maskPhone(phone: string) {
  const d = phone.replace(/\D/g, "");
  return d.length < 6 ? "***" : `${d.slice(0, 3)}*****${d.slice(-2)}`;
}

/**
 * Sürücü adaylığı.
 * - Telefon maskelenerek saklanır (PII).
 * - Belgeler için kayıt açılır ama dosya SAĞLAYICI YOK: yalnızca meta veri.
 * - Ticari yolcu taşıma belgesi doğrulanmadan sürücü çevrimiçi olamaz.
 */
export async function POST(req: Request) {
  const user = await requireAuth();
  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`chauffeur-apply:${ip}`, 5, 10 * 60_000)) {
    return Response.json({ error: "Çok fazla başvuru denemesi." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Başvuru eksik" }, { status: 400 });
  }
  const input = parsed.data;

  const existingProfile = user
    ? await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1)
    : [];
  if (existingProfile.length > 0) {
    return Response.json({ error: "Bu hesap için zaten sürücü kaydı var." }, { status: 409 });
  }

  const [application] = await db
    .insert(chauffeurApplications)
    .values({
      fullName: input.fullName,
      phoneMasked: maskPhone(input.phone),
      city: input.city,
      vehicleType: input.vehicleType,
      ownership: input.ownership,
      hasCommercialLicense: input.hasCommercialLicense,
      experienceYears: input.experienceYears,
      note: input.note ?? "",
      userId: user?.id ?? null,
      status: "belge_bekliyor",
    })
    .returning();

  let profileId: number | null = null;
  if (user) {
    const [profile] = await db
      .insert(chauffeurProfiles)
      .values({
        userId: user.id,
        fullName: input.fullName,
        phoneMasked: maskPhone(input.phone),
        city: input.city,
        status: "belge_bekliyor",
        verificationLevel: "temel",
        isDemo: false,
      })
      .returning();
    profileId = profile.id;

    for (const docType of DOC_TYPES) {
      await db.insert(chauffeurDocuments).values({ chauffeurId: profile.id, docType, status: "not_uploaded" });
    }

    if (input.plate) {
      await db.insert(chauffeurVehicles).values({
        chauffeurId: profile.id,
        plate: input.plate.toUpperCase(),
        vehicleType: input.vehicleType,
        ownership: input.ownership,
        documentsVerified: false,
        isActive: false,
      });
    }
  }

  await writeAudit({
    actorId: user?.id ?? null,
    actorRole: user?.role ?? "anonim",
    action: "surucu_basvurusu",
    entity: "chauffeur_application",
    entityId: String(application.id),
    meta: { vehicleType: input.vehicleType, hasCommercialLicense: input.hasCommercialLicense },
  });

  return Response.json({
    ok: true,
    applicationId: application.id,
    profileId,
    requiredDocuments: DOC_TYPES,
    notice:
      "Dosya depolama sağlayıcısı bağlı değil: belgeler bu sürümde yüklenemez, yalnızca kayıt açılır. Ticari yolcu taşıma belgeleri doğrulanmadan çevrimiçi olamazsınız.",
  });
}

/** Belge durumu — aday kendi kaydını görür. */
export async function GET() {
  const user = await requireAuth();
  if (!user) return Response.json({ error: "Oturum gerekli" }, { status: 401 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) {
    const [application] = await db
      .select()
      .from(chauffeurApplications)
      .where(eq(chauffeurApplications.userId, user.id))
      .limit(1);
    return Response.json({ profile: null, application: application ?? null });
  }

  const documents = await db.select().from(chauffeurDocuments).where(eq(chauffeurDocuments.chauffeurId, profile.id));
  const vehicles = await db.select().from(chauffeurVehicles).where(eq(chauffeurVehicles.chauffeurId, profile.id));

  return Response.json({ profile, documents, vehicles });
}

