import { db } from "@/db";
import { couriers, orgMembers, organizations, users } from "@/db/schema";
import { and, desc, eq, isNull, like, or, sql } from "drizzle-orm";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { ROLE_LABEL, type Role } from "@/lib/auth";

export const dynamic = "force-dynamic";

function maskEmail(value: string | null): string {
  if (!value) return "";
  const [name, domain] = value.split("@");
  if (!domain) return "***";
  return `${name.slice(0, 2)}***@${domain}`;
}

function maskPhone(value: string | null): string {
  if (!value) return "";
  const digits = value.replace(/\D/g, "");
  if (digits.length < 6) return "***";
  return `${digits.slice(0, 3)}*****${digits.slice(-2)}`;
}

/**
 * Üye listesi.
 * - Parola, erişim kodu ve TOTP sırrı HİÇBİR zaman dönmez.
 * - E-posta/telefon `member:sensitive` izni yoksa maskelenir.
 * - İşletme rolü yalnızca KENDİ tenant'ının üyelerini görür (sunucu tarafı filtre).
 * - Arşivlenmiş kayıtlar varsayılan olarak gizlidir.
 */
export async function GET(req: Request) {
  const user = await requirePermission("member:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const url = new URL(req.url);
  const query = (url.searchParams.get("q") ?? "").trim();
  const role = url.searchParams.get("role") ?? "";
  const status = url.searchParams.get("status") ?? "";
  const includeArchived = url.searchParams.get("archived") === "1";
  const page = Math.max(0, Number(url.searchParams.get("page") ?? 0));
  const pageSize = Math.min(100, Math.max(5, Number(url.searchParams.get("pageSize") ?? 25)));

  const canSeeSensitive = hasPermission(user.role, "member:sensitive");
  const scopedToOrg = user.role === "isletme_sahibi" || user.role === "isletme_calisani";

  const conditions = [];
  if (!includeArchived) conditions.push(isNull(users.archivedAt));
  if (role && role in ROLE_LABEL) conditions.push(eq(users.role, role));
  if (query) {
    const pattern = `%${query}%`;
    conditions.push(or(like(users.fullName, pattern), like(users.email, pattern)) as never);
  }
  if (status === "aktif") conditions.push(eq(users.isActive, true), eq(users.isBanned, false));
  if (status === "pasif") conditions.push(eq(users.isActive, false));
  if (status === "banli") conditions.push(eq(users.isBanned, true));
  if (status === "dogrulanmamis") conditions.push(isNull(users.kvkkConsentAt));

  let scopedIds: number[] | null = null;
  if (scopedToOrg) {
    if (!user.orgId) return Response.json({ rows: [], total: 0, scoped: true });
    const memberRows = await db.select({ userId: orgMembers.userId }).from(orgMembers).where(eq(orgMembers.orgId, user.orgId));
    scopedIds = [user.id, ...memberRows.map((m) => m.userId)];
    if (scopedIds.length === 0) return Response.json({ rows: [], total: 0, scoped: true });
  }

  const where = scopedIds
    ? and(sql`${users.id} IN (${sql.join(scopedIds.map((id) => sql`${id}`), sql`, `)})`, ...conditions)
    : conditions.length
      ? and(...conditions)
      : undefined;

  const [countRow] = await db.select({ n: sql<number>`count(*)` }).from(users).where(where);
  const total = Number(countRow?.n ?? 0);

  const rows = await db
    .select()
    .from(users)
    .where(where)
    .orderBy(desc(users.createdAt))
    .limit(pageSize)
    .offset(page * pageSize);

  const orgRows = await db.select().from(organizations);
  const orgById = new Map(orgRows.map((o) => [o.id, o]));
  const courierRows = await db.select().from(couriers);
  const courierByUser = new Map(courierRows.map((c) => [c.userId, c]));

  return Response.json({
    total,
    page,
    pageSize,
    scoped: scopedToOrg,
    canSeeSensitive,
    rows: rows.map((row) => {
      const courier = courierByUser.get(row.id);
      return {
        id: row.id,
        fullName: row.fullName,
        // Hassas alanlar izin yoksa maskeli döner.
        email: canSeeSensitive ? row.email : maskEmail(row.email),
        phone: canSeeSensitive ? (row.phone ?? "") : maskPhone(row.phone),
        role: row.role,
        roleLabel: ROLE_LABEL[row.role as Role] ?? row.role,
        orgName: row.orgId ? (orgById.get(row.orgId)?.name ?? "") : "",
        isActive: row.isActive,
        isBanned: row.isBanned,
        archived: row.archivedAt !== null,
        mfaEnabled: row.totpEnabled,
        mustChangePassword: row.mustChangePassword,
        verified: row.kvkkConsentAt !== null,
        lastLoginAt: row.lastLoginAt,
        createdAt: row.createdAt,
        courierStatus: courier?.status ?? null,
        courierCity: courier?.city ?? null,
      };
    }),
  });
}
