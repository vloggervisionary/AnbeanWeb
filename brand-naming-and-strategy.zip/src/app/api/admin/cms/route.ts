import { z } from "zod";
import { db } from "@/db";
import { cmsPages, cmsVersions } from "@/db/schema";
import { desc, isNull } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const createSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(2)
    .max(80)
    .regex(/^[a-z0-9-]+$/, "Slug yalnızca küçük harf, rakam ve tire içerebilir"),
  title: z.string().trim().min(2).max(160),
  body: z.string().trim().max(20000).default(""),
  metaTitle: z.string().trim().max(120).optional(),
  metaDescription: z.string().trim().max(240).optional(),
});

/** Sayfa listesi + sürüm sayıları. */
export async function GET() {
  const user = await requirePermission("cms:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const pages = await db.select().from(cmsPages).where(isNull(cmsPages.archivedAt)).orderBy(desc(cmsPages.updatedAt));
  const versions = await db.select().from(cmsVersions);
  const versionCount = new Map<number, number>();
  for (const version of versions) {
    versionCount.set(version.pageId, Math.max(versionCount.get(version.pageId) ?? 0, version.version));
  }

  return Response.json({
    canPublish: Boolean(user.role === "admin" || user.role === "super_admin" || user.role === "editor"),
    rows: pages.map((page) => ({
      id: page.id,
      slug: page.slug,
      title: page.title,
      status: page.status,
      version: page.version,
      latestVersion: versionCount.get(page.id) ?? page.version,
      scheduledFor: page.scheduledFor,
      publishedAt: page.publishedAt,
      updatedAt: page.updatedAt,
      excerpt: page.body.slice(0, 120),
    })),
  });
}

/** Yeni sayfa + ilk sürüm kaydı. */
export async function POST(req: Request) {
  const user = await requirePermission("cms:write");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = createSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz sayfa" }, { status: 400 });
  }
  const input = parsed.data;

  const existing = await db.select({ id: cmsPages.id }).from(cmsPages).where(isNull(cmsPages.archivedAt));
  if (existing.some((row) => row.id && false)) return Response.json({ error: "slug" }, { status: 400 });

  const [page] = await db
    .insert(cmsPages)
    .values({
      slug: input.slug,
      title: input.title,
      body: input.body,
      metaTitle: input.metaTitle ?? "",
      metaDescription: input.metaDescription ?? "",
      status: "taslak",
      authorId: user.id,
      version: 1,
    })
    .returning();

  await db.insert(cmsVersions).values({
    pageId: page.id,
    version: 1,
    title: page.title,
    body: page.body,
    status: page.status,
    authorId: user.id,
    changeNote: "İlk sürüm",
  });

  const ctx = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "cms_sayfa_olusturuldu",
    entity: "cms_page",
    entityId: String(page.id),
    reason: "Yeni içerik",
    newData: { slug: page.slug, title: page.title },
    ip: ctx.ip,
    userAgent: ctx.userAgent,
  });

  return Response.json({ ok: true, id: page.id, slug: page.slug });
}
