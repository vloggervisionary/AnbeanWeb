import { z } from "zod";
import { db } from "@/db";
import { cmsPages, cmsVersions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const patchSchema = z.object({
  title: z.string().trim().min(2).max(160).optional(),
  body: z.string().trim().max(20000).optional(),
  metaTitle: z.string().trim().max(120).optional(),
  metaDescription: z.string().trim().max(240).optional(),
  status: z.enum(["taslak", "incelemede", "yayinda", "arsiv"]).optional(),
  scheduledFor: z.string().trim().optional(),
  changeNote: z.string().trim().min(3, "Değişiklik özeti zorunlu").max(200),
});

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("cms:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const [page] = await db.select().from(cmsPages).where(eq(cmsPages.id, id)).limit(1);
  if (!page) return Response.json({ error: "Sayfa bulunamadı" }, { status: 404 });

  const versions = await db
    .select()
    .from(cmsVersions)
    .where(eq(cmsVersions.pageId, id))
    .orderBy(desc(cmsVersions.version));

  return Response.json({ page, versions });
}

/**
 * Kaydetme: eski içerik ÖNCE sürüm olarak yazılır, sonra yenisi uygulanır.
 * Böylece yayınlanmış içerik değiştiğinde önceki sürüm her zaman geri yüklenebilir.
 */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("cms:write");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const [page] = await db.select().from(cmsPages).where(eq(cmsPages.id, id)).limit(1);
  if (!page) return Response.json({ error: "Sayfa bulunamadı" }, { status: 404 });

  const parsed = patchSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz içerik" }, { status: 400 });
  }
  const input = parsed.data;

  // Yayına alma izni ayrıdır: editör yazabilir, yayın için cms:publish gerekir.
  if (input.status === "yayinda") {
    const publisher = await requirePermission("cms:publish");
    if (!publisher) return Response.json({ error: "Yayınlama yetkin yok." }, { status: 403 });
  }

  const nextVersion = page.version + 1;
  const scheduledFor = input.scheduledFor ? new Date(input.scheduledFor) : page.scheduledFor;

  await db.insert(cmsVersions).values({
    pageId: id,
    version: nextVersion,
    title: input.title ?? page.title,
    body: input.body ?? page.body,
    status: input.status ?? page.status,
    authorId: user.id,
    changeNote: input.changeNote,
  });

  const [updated] = await db
    .update(cmsPages)
    .set({
      title: input.title ?? page.title,
      body: input.body ?? page.body,
      metaTitle: input.metaTitle ?? page.metaTitle,
      metaDescription: input.metaDescription ?? page.metaDescription,
      status: input.status ?? page.status,
      scheduledFor,
      publishedAt: (input.status ?? page.status) === "yayinda" ? (page.publishedAt ?? new Date()) : page.publishedAt,
      version: nextVersion,
      authorId: user.id,
      updatedAt: new Date(),
    })
    .where(eq(cmsPages.id, id))
    .returning();

  const ctxInfo = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "cms_sayfa_guncellendi",
    entity: "cms_page",
    entityId: String(id),
    reason: input.changeNote,
    oldData: { title: page.title, status: page.status, version: page.version },
    newData: { title: updated.title, status: updated.status, version: updated.version },
    ip: ctxInfo.ip,
    userAgent: ctxInfo.userAgent,
  });

  return Response.json({ ok: true, page: updated, version: nextVersion });
}

/** Yayınla / arşivle / sürüm geri yükle. */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const id = Number((await ctx.params).id);
  const [page] = await db.select().from(cmsPages).where(eq(cmsPages.id, id)).limit(1);
  if (!page) return Response.json({ error: "Sayfa bulunamadı" }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as { action?: string; version?: number; reason?: string };
  const action = String(body.action ?? "");
  const reason = String(body.reason ?? "").trim();
  const ctxInfo = await requestContext();

  if (action === "archive") {
    const user = await requirePermission("cms:publish");
    if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });
    if (reason.length < 5) return Response.json({ error: "Arşivleme için gerekçe zorunlu." }, { status: 400 });
    await db.update(cmsPages).set({ archivedAt: new Date(), status: "arsiv" }).where(eq(cmsPages.id, id));
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "cms_sayfa_arsivlendi",
      entity: "cms_page",
      entityId: String(id),
      reason,
      ip: ctxInfo.ip,
      userAgent: ctxInfo.userAgent,
    });
    return Response.json({ ok: true });
  }

  if (action === "restore") {
    const user = await requirePermission("cms:restore");
    if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });
    const versionNumber = Number(body.version);
    if (!Number.isFinite(versionNumber)) return Response.json({ error: "Sürüm numarası gerekli" }, { status: 400 });

    const [target] = await db
      .select()
      .from(cmsVersions)
      .where(eq(cmsVersions.pageId, id))
      .limit(200);
    const all = await db.select().from(cmsVersions).where(eq(cmsVersions.pageId, id));
    const source = all.find((v) => v.version === versionNumber);
    void target;
    if (!source) return Response.json({ error: "Sürüm bulunamadı" }, { status: 404 });

    // Geri yükleme de YENİ sürüm olarak yazılır: geçmiş silinmez.
    const nextVersion = page.version + 1;
    await db.insert(cmsVersions).values({
      pageId: id,
      version: nextVersion,
      title: source.title,
      body: source.body,
      status: "taslak",
      authorId: user.id,
      changeNote: `v${versionNumber} sürümünden geri yüklendi`,
    });
    await db
      .update(cmsPages)
      .set({ title: source.title, body: source.body, status: "taslak", version: nextVersion, updatedAt: new Date() })
      .where(eq(cmsPages.id, id));

    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "cms_surum_geri_yuklendi",
      entity: "cms_page",
      entityId: String(id),
      reason: reason || `v${versionNumber} geri yüklendi`,
      oldData: { version: page.version },
      newData: { version: nextVersion, restoredFrom: versionNumber },
      ip: ctxInfo.ip,
      userAgent: ctxInfo.userAgent,
    });
    return Response.json({ ok: true, version: nextVersion, restoredFrom: versionNumber });
  }

  return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
}
