import { z } from "zod";
import { db } from "@/db";
import { courierCv, courierCvItems, couriers } from "@/db/schema";
import { and, asc, eq, isNull } from "drizzle-orm";
import { getSessionUser, requirePermission, writeAudit } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const KINDS = ["experience", "education", "skill", "certification", "language", "service_area", "portfolio"] as const;
const VISIBILITY = ["herkse_acik", "personele_acik", "gizli"] as const;

const cvSchema = z.object({
  displayName: z.string().trim().max(80).optional(),
  about: z.string().trim().max(1200).optional(),
  photoRef: z.string().trim().max(200).optional(),
  defaultVisibility: z.enum(VISIBILITY).optional(),
  availabilityNote: z.string().trim().max(300).optional(),
  vehicleNote: z.string().trim().max(300).optional(),
  profilePublished: z.boolean().optional(),
});

const itemSchema = z.object({
  itemId: z.number().int().positive().optional(),
  kind: z.enum(KINDS),
  title: z.string().trim().min(1, "Başlık zorunlu").max(140),
  org: z.string().trim().max(140).optional(),
  startsAt: z.string().trim().max(20).optional(),
  endsAt: z.string().trim().max(20).optional(),
  description: z.string().trim().max(1000).optional(),
  visibility: z.enum(VISIBILITY).optional(),
  sortIndex: z.number().int().min(0).max(999).optional(),
});

/**
 * Kurye CV'si.
 * - `gizli` görünürlüklü kalemler yalnızca `member:sensitive` izni olan role döner.
 * - Dosya sağlayıcısı yok: fotoğraf yalnızca referans metni olarak tutulur,
 *   içerik yüklenmez (yükleme bağlanmadan "yüklendi" gösterilmez).
 */
export async function GET(_req: Request, ctx: { params: Promise<{ courierId: string }> }) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Oturum gerekli" }, { status: 401 });

  const courierId = Number((await ctx.params).courierId);
  const [courier] = await db.select().from(couriers).where(eq(couriers.id, courierId)).limit(1);
  if (!courier) return Response.json({ error: "Kurye bulunamadı" }, { status: 404 });

  // Kurye kendi CV'sini her zaman görür; başkaları cv:read izniyle.
  const user = session;
  const isSelf = courier.userId === user.id;
  if (!isSelf && !hasPermission(user.role, "cv:read")) {
    return Response.json({ error: "Yetkisiz" }, { status: 403 });
  }
  const canSeeHidden = isSelf || hasPermission(user.role, "member:sensitive");

  const [cv] = await db.select().from(courierCv).where(eq(courierCv.courierId, courierId)).limit(1);
  const items = cv
    ? await db
        .select()
        .from(courierCvItems)
        .where(and(eq(courierCvItems.cvId, cv.id), isNull(courierCvItems.archivedAt)))
        .orderBy(asc(courierCvItems.sortIndex))
    : [];

  return Response.json({
    courier: { id: courier.id, fullName: courier.fullName, city: courier.city, vehicle: courier.vehicle, status: courier.status },
    cv: cv ?? null,
    canEdit: isSelf || hasPermission(user.role, "cv:manage"),
    items: items
      .filter((item) => canSeeHidden || item.visibility !== "gizli")
      .map((item) => ({
        ...item,
        // Gizli kalem yetkisize hiç dönmez; yetkiliye içeriğiyle döner.
      })),
    kinds: KINDS,
  });
}

/** CV başlık alanlarını günceller (PUT = upsert). */
export async function PUT(req: Request, ctx: { params: Promise<{ courierId: string }> }) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Oturum gerekli" }, { status: 401 });
  const courierId = Number((await ctx.params).courierId);
  const [courier] = await db.select().from(couriers).where(eq(couriers.id, courierId)).limit(1);
  if (!courier) return Response.json({ error: "Kurye bulunamadı" }, { status: 404 });

  // Kurye kendi CV'sini düzenleyebilir; başkası cv:manage izniyle.
  const user = session;
  const isSelf = courier.userId === user.id;
  if (!isSelf && !hasPermission(user.role, "cv:manage")) {
    return Response.json({ error: "Yetkisiz" }, { status: 403 });
  }

  const parsed = cvSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz CV alanı" }, { status: 400 });
  }

  const [existing] = await db.select().from(courierCv).where(eq(courierCv.courierId, courierId)).limit(1);
  const values = { ...parsed.data, updatedAt: new Date() };
  const cv = existing
    ? (await db.update(courierCv).set(values).where(eq(courierCv.id, existing.id)).returning())[0]
    : (await db.insert(courierCv).values({ ...values, courierId }).returning())[0];

  const context = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "cv_guncellendi",
    entity: "courier_cv",
    entityId: String(cv.id),
    reason: "CV alanları düzenlendi",
    oldData: existing ? { displayName: existing.displayName, about: existing.about.slice(0, 80) } : {},
    newData: { displayName: cv.displayName, about: cv.about.slice(0, 80) },
    ip: context.ip,
    userAgent: context.userAgent,
  });

  return Response.json({ ok: true, cv });
}

/** CV kalemi ekler/günceller/arşivler. */
export async function POST(req: Request, ctx: { params: Promise<{ courierId: string }> }) {
  const session = await getSessionUser();
  if (!session) return Response.json({ error: "Oturum gerekli" }, { status: 401 });
  const courierId = Number((await ctx.params).courierId);
  const [courier] = await db.select().from(couriers).where(eq(couriers.id, courierId)).limit(1);
  if (!courier) return Response.json({ error: "Kurye bulunamadı" }, { status: 404 });
  const user = session;
  const isSelf = courier.userId === user.id;
  if (!isSelf && !hasPermission(user.role, "cv:manage")) {
    return Response.json({ error: "Yetkisiz" }, { status: 403 });
  }

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const mode = String(body.mode ?? "upsert");

  const [cv] = await db.select().from(courierCv).where(eq(courierCv.courierId, courierId)).limit(1);
  if (!cv) return Response.json({ error: "Önce CV başlığı kaydedilmeli" }, { status: 409 });

  if (mode === "archive") {
    const itemId = Number(body.itemId);
    if (!Number.isFinite(itemId)) return Response.json({ error: "Geçersiz kalem" }, { status: 400 });
    // Kalıcı silme yok: arşivleme.
    await db.update(courierCvItems).set({ archivedAt: new Date() }).where(and(eq(courierCvItems.id, itemId), eq(courierCvItems.cvId, cv.id)));
    await writeAudit({ actorId: user.id, actorRole: user.role, action: "cv_kalemi_arsivlendi", entity: "courier_cv_item", entityId: String(itemId), reason: String(body.reason ?? "Arşivlendi") });
    return Response.json({ ok: true });
  }

  const parsed = itemSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz kalem" }, { status: 400 });
  }
  const input = parsed.data;
  const { itemId, ...values } = input;

  if (itemId) {
    const [updated] = await db
      .update(courierCvItems)
      .set(values)
      .where(and(eq(courierCvItems.id, itemId), eq(courierCvItems.cvId, cv.id)))
      .returning();
    if (!updated) return Response.json({ error: "Kalem bulunamadı" }, { status: 404 });
    return Response.json({ ok: true, item: updated });
  }

  const [created] = await db.insert(courierCvItems).values({ ...values, cvId: cv.id }).returning();
  return Response.json({ ok: true, item: created });
}
