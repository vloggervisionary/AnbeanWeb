import { z } from "zod";
import { db } from "@/db";
import { emailTemplates, platformSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const schema = z.object({
  target: z.enum(["setting", "template"]),
  key: z.string().trim().min(2).max(60),
  value: z.unknown().optional(),
  subject: z.string().trim().max(200).optional(),
  body: z.string().trim().max(4000).optional(),
  isActive: z.boolean().optional(),
  reason: z.string().trim().min(5, "Gerekçe zorunlu").max(200),
});

/** Platform ayarları ve bildirim şablonları. Gizli anahtarlar burada tutulmaz. */
export async function GET() {
  const user = await requirePermission("settings:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const [settings, templates] = await Promise.all([db.select().from(platformSettings), db.select().from(emailTemplates)]);
  return Response.json({
    settings: settings.map((row) => ({ key: row.key, value: row.value, updatedAt: row.updatedAt })),
    templates: templates.map((row) => ({
      id: row.id,
      key: row.key,
      name: row.name,
      channel: row.channel,
      subject: row.subject,
      body: row.body,
      isActive: row.isActive,
      updatedAt: row.updatedAt,
    })),
  });
}

export async function PATCH(req: Request) {
  const user = await requirePermission("settings:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz istek" }, { status: 400 });
  }
  const input = parsed.data;
  const ctx = await requestContext();

  if (input.target === "setting") {
    const [existing] = await db.select().from(platformSettings).where(eq(platformSettings.key, input.key)).limit(1);
    if (existing) {
      await db.update(platformSettings).set({ value: input.value, updatedBy: user.id, updatedAt: new Date() }).where(eq(platformSettings.id, existing.id));
    } else {
      await db.insert(platformSettings).values({ key: input.key, value: input.value, updatedBy: user.id });
    }
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "platform_ayari_degisti",
      entity: "platform_setting",
      entityId: input.key,
      reason: input.reason,
      oldData: { value: existing?.value ?? null },
      newData: { value: input.value },
      ip: ctx.ip,
      userAgent: ctx.userAgent,
    });
    return Response.json({ ok: true });
  }

  const [template] = await db.select().from(emailTemplates).where(eq(emailTemplates.key, input.key)).limit(1);
  if (!template) return Response.json({ error: "Şablon bulunamadı" }, { status: 404 });
  await db
    .update(emailTemplates)
    .set({
      subject: input.subject ?? template.subject,
      body: input.body ?? template.body,
      isActive: input.isActive ?? template.isActive,
      updatedAt: new Date(),
    })
    .where(eq(emailTemplates.id, template.id));

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "bildirim_sablonu_guncellendi",
    entity: "email_template",
    entityId: template.key,
    reason: input.reason,
    oldData: { subject: template.subject, isActive: template.isActive },
    newData: { subject: input.subject ?? template.subject, isActive: input.isActive ?? template.isActive },
    ip: ctx.ip,
    userAgent: ctx.userAgent,
  });

  return Response.json({ ok: true });
}
