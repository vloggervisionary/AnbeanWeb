import Link from "next/link";
import { headers } from "next/headers";
import { db } from "@/db";
import {
  chauffeurProfiles,
  chauffeurVehicles,
  passengerRideRequests,
  passengerRides,
  rideShareSessions,
} from "@/db/schema";
import { and, eq, isNull, sql } from "drizzle-orm";
import { BrandMark } from "@/components/SiteChrome";
import { RIDE_STATUS_LABEL_LOCAL } from "@/lib/hail-types";
import { rateLimit } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Canlı yolculuk paylaşımı — Anbean",
  robots: { index: false, follow: false },
};

function coarsen(value: number | null): number | null {
  if (value === null) return null;
  return Math.round(value * 200) / 200;
}

/**
 * Güvenilen kişi görünümü.
 * GÖSTERİLİR: plaka, sürücünün adı (soyadsız), yaklaşık konum (~500 m), durum, acil durum.
 * GÖSTERİLMEZ: yolcu telefonu, tam adres, ücret, ödeme bilgisi.
 */
export default async function PaylasimPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  const allowed = token.length >= 20 && token.length <= 64 && rateLimit(`share-page:${ip}`, 60, 60_000);

  const [session] = allowed
    ? await db
        .select()
        .from(rideShareSessions)
        .where(and(eq(rideShareSessions.token, token), isNull(rideShareSessions.revokedAt)))
        .limit(1)
    : [];

  const invalid = (reason: string) => (
    <main className="flex min-h-screen flex-col items-center justify-center bg-deep px-5 text-center">
      <div className="text-white">
        <BrandMark />
      </div>
      <h1 className="mt-8 font-display text-2xl font-bold text-white">Bağlantı kullanılamıyor</h1>
      <p className="mt-3 max-w-md text-sm text-slate-400">{reason}</p>
      <Link href="/" className="mt-6 inline-block rounded-md bg-accent px-5 py-3 text-sm font-semibold text-[#0B1220]">
        Ana sayfa
      </Link>
    </main>
  );

  if (!allowed) return invalid("Bağlantı geçersiz veya çok fazla deneme yapıldı.");
  if (!session || session.expiresAt.getTime() < Date.now()) return invalid("Bağlantının süresi dolmuş veya iptal edilmiş.");

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, session.rideId)).limit(1);
  if (!ride) return invalid("Yolculuk bulunamadı.");

  await db
    .update(rideShareSessions)
    .set({ hitCount: sql`${rideShareSessions.hitCount} + 1`, lastHitAt: new Date() })
    .where(eq(rideShareSessions.id, session.id));

  const finished = ["COMPLETED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW"].includes(ride.status);
  if (finished) {
    await db.update(rideShareSessions).set({ revokedAt: new Date() }).where(eq(rideShareSessions.id, session.id));
    return invalid("Yolculuk sona erdi; canlı paylaşım otomatik kapatıldı.");
  }

  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  const [profile] = ride.chauffeurId
    ? await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.id, ride.chauffeurId)).limit(1)
    : [];
  const [vehicle] = ride.vehicleId
    ? await db.select().from(chauffeurVehicles).where(eq(chauffeurVehicles.id, ride.vehicleId)).limit(1)
    : [];

  return (
    <main className="min-h-screen bg-deep px-5 py-10">
      <div className="mx-auto max-w-lg">
        <div className="text-white">
          <BrandMark size="sm" />
        </div>
        <p className="mt-8 text-[11px] uppercase tracking-[0.18em] text-slate-500">Canlı yolculuk paylaşımı</p>
        <h1 className="mt-2 font-display text-3xl font-bold text-white" role="status">
          {RIDE_STATUS_LABEL_LOCAL[ride.status] ?? ride.status}
        </h1>
        <p className="mt-2 text-sm text-slate-400">
          {request?.pickupDistrict} → {request?.dropDistrict}
        </p>

        {vehicle ? (
          <div className="mt-6 rounded-lg border border-white/10 bg-white/3 p-5">
            <p className="font-display text-2xl font-bold tracking-wider text-white">{vehicle.plate}</p>
            <p className="mt-1 text-sm text-slate-300">
              {vehicle.make} {vehicle.model} · {vehicle.color}
            </p>
            {profile ? (
              <p className="mt-3 text-sm text-slate-300">
                Sürücü: {profile.fullName.split(" ")[0]}
                {profile.isDemo ? " (demo)" : ""}
              </p>
            ) : null}
          </div>
        ) : (
          <p className="mt-6 rounded-lg border border-white/10 bg-white/3 p-5 text-sm text-slate-400">
            Henüz sürücü atanmadı.
          </p>
        )}

        <div className="mt-4 rounded-lg border border-white/10 bg-white/3 p-5">
          <p className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Yaklaşık konum</p>
          <p className="mt-2 font-mono text-sm text-slate-300">
            {coarsen(profile?.lastLat ?? null) ?? "—"} , {coarsen(profile?.lastLng ?? null) ?? "—"}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">
            Konum ~500 m hassasiyetle yuvarlanır. Kesin konum, yolcu telefonu, tam adres ve ödeme bilgisi bu sayfada
            paylaşılmaz.
          </p>
        </div>

        <div className="mt-4 rounded-lg border border-st-risk/40 bg-st-risk/8 p-5">
          <p className="text-sm font-semibold text-white">Acil durum</p>
          <p className="mt-1.5 text-sm text-slate-300">
            Tehlike varsa önce 112&apos;yi ara. Yolcu ayrıca uygulama içinden güvenlik olayı bildirebilir.
          </p>
          <a href="tel:112" className="mt-3 inline-block rounded-md bg-st-risk px-5 py-3 text-sm font-semibold text-white">
            112&apos;yi ara
          </a>
        </div>

        <p className="mt-6 text-[11px] text-slate-600">
          Bu bağlantı {new Date(session.expiresAt).toLocaleString("tr-TR")} tarihinde geçerliliğini yitirir ve
          yolculuk bittiğinde otomatik kapanır.
        </p>
      </div>
    </main>
  );
}
