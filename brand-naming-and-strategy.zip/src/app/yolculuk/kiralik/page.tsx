import Link from "next/link";
import { db } from "@/db";
import { iotVehicles } from "@/db/schema";
import PageShell from "@/components/PageShell";
import Reveal from "@/components/Reveal";
import { STATE_COPY } from "@/lib/content";
import { formatTry } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Kiralık yolculuk — Anbean",
  description: "Elektrikli scooter, e-bisiklet ve moped kiralama. Kilit açma sunucuda doğrulanır, ücret dakika bazlıdır.",
};

export default async function KiralikPage() {
  const vehicles = await db.select().from(iotVehicles).catch(() => []);
  const ready = vehicles.filter((v) => v.status === "available" && v.batteryPercent >= 20);
  const byKind = new Map<string, number>();
  for (const v of ready) byKind.set(v.kind, (byKind.get(v.kind) ?? 0) + 1);
  const minPrice = ready.length ? Math.min(...ready.map((v) => v.perMinuteKurus)) : null;

  return (
    <PageShell
      eyebrow="Yolculuk · kiralık"
      title="Aracı kendin sür"
      lead="Elektrikli filo: scooter, e-bisiklet, moped. Kilit açma isteği sunucuda doğrulanır; tarayıcı kilidi kendi başına açamaz."
    >
      <Reveal>
        <div className="grid gap-4 sm:grid-cols-4">
          {[
            { label: "Kiralanabilir", value: String(ready.length) },
            { label: "Scooter", value: String(byKind.get("scooter") ?? 0) },
            { label: "E-bisiklet", value: String(byKind.get("ebike") ?? 0) },
            { label: "Dakika ücreti", value: minPrice === null ? "—" : `${formatTry(minPrice)}'den` },
          ].map((stat) => (
            <div key={stat.label} className="rounded-lg border border-white/10 bg-white/3 p-5">
              <p className="text-[11px] uppercase tracking-[0.12em] text-slate-500">{stat.label}</p>
              <p className="mt-2 font-display text-2xl font-bold text-white">{stat.value}</p>
            </div>
          ))}
        </div>
      </Reveal>

      <Reveal delay={0.05} className="mt-8">
        <div className="rounded-lg border border-sur/30 bg-sur/8 p-6">
          <ol className="grid gap-4 sm:grid-cols-3">
            {[
              { n: "1", t: "Aracı seç", d: "Haritada müsait araçlar yeşil, bataryası düşük olanlar kehribar." },
              { n: "2", t: "Kilidi aç", d: "İstek sunucuda doğrulanır; bataryası %20'nin altındaki araç açılamaz." },
              { n: "3", t: "Bitir ve kilitle", d: "Süre × dakika ücreti hesaplanır, platform bakiyenden düşer." },
            ].map((step) => (
              <li key={step.n} className="rounded-md border border-white/8 bg-white/3 p-4">
                <span className="font-display text-2xl font-bold text-sur">{step.n}</span>
                <p className="mt-2 text-sm font-semibold text-white">{step.t}</p>
                <p className="mt-1 text-xs text-slate-400">{step.d}</p>
              </li>
            ))}
          </ol>
          <Link
            href="/filo-haritasi"
            className="mt-6 inline-block rounded-md bg-accent px-6 py-3 text-sm font-semibold text-[#0B1220] transition hover:bg-accent-soft"
          >
            Haritada araç bul
          </Link>
        </div>
      </Reveal>

      <Reveal delay={0.1} className="mt-6 grid gap-5 md:grid-cols-2">
        <div className="rounded-lg border border-white/10 bg-white/3 p-6">
          <h2 className="text-lg font-semibold text-white">Güvenlik ve kurallar</h2>
          <ul className="mt-3 space-y-2 text-sm text-slate-400">
            <li>· Kask önerilir; yerel hız sınırları ve trafik kuralları geçerlidir.</li>
            <li>· Kırmızı alanlar park yasağı bölgesidir.</li>
            <li>· Konum verisi yalnızca kiralama süresince toplanır.</li>
            <li>· Demoda araç konumu simüle edildiği için bölge kuralları sürüşe henüz uygulanmıyor.</li>
          </ul>
          <Link href="/yasal/mobilite-kiralama-kosullari" className="mt-4 inline-block text-sm font-semibold text-accent">
            Kiralama koşulları (taslak) →
          </Link>
        </div>
        <div className="rounded-lg border border-white/10 bg-white/3 p-6">
          <h2 className="text-lg font-semibold text-white">Sürücülü yolculuk mu arıyorsun?</h2>
          <p className="mt-2 text-sm text-slate-400">{STATE_COPY.noDriverService.body}</p>
          <p className="mt-3 text-xs text-slate-500">
            Güncelleme: sürücülü yolculuk modülü pilot olarak kuruldu. Belgesi doğrulanmış sürücülerle akış
            uçtan uca çalışır; canlı hizmet açılışı hukuk onayına bağlıdır.
          </p>
          <Link href="/yolculuk/suruculu" className="mt-4 inline-block text-sm font-semibold text-accent">
            Sürücülü yolculuk →
          </Link>
        </div>
      </Reveal>
    </PageShell>
  );
}
