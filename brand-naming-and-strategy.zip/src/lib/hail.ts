import { db } from "@/db";
import {
  chauffeurOffers,
  chauffeurProfiles,
  chauffeurTariffs,
  chauffeurVehicles,
  passengerRideEvents,
  passengerRides,
  wallets,
} from "@/db/schema";
import { and, eq, inArray, isNull, sql } from "drizzle-orm";
import { ensureWallet, postLedger } from "./ledger";
import { writeAudit } from "./auth";
import { hashToken, newOtp, verifyOtp } from "./password";

/**
 * SÜRÜCÜLÜ YOLCULUK ÇEKİRDEĞİ
 *
 * Kararlar (brif yerine verilen, gerekçeli):
 *  - Model: HİBRİT mimari, ama varsayılan yapılandırma yalnızca TİCARİ BELGESİ
 *    DOĞRULANMIŞ sürücülerle çalışır. Özel araç (TAG benzeri) eşleştirmesi
 *    `ALLOW_PRIVATE_CAR_MATCHING` bayrağı arkasındadır ve VARSAYILAN KAPALI.
 *    Hukuk onayı olmadan açılamaz.
 *  - Fiyat: ön teklif sunucuda kilitlenir, yolculuk sonunda gerçek mesafe/süre
 *    ile YENİDEN hesaplanır; fark yolcuya açık gösterilir.
 *  - Cinsiyet bazlı eşleştirme YOK (ayrımcılık mevzuatı riski).
 *  - Ses kaydı ve biyometrik YOK.
 */

export const ALLOW_PRIVATE_CAR_MATCHING = process.env.ALLOW_PRIVATE_CAR_MATCHING === "true";

/**
 * Ticari yolcu taşıma için zorunlu belgeler.
 * TAMAMI onaylanmadan sürücü doğrulanmış sayılmaz ve teklif alamaz.
 */
export const REQUIRED_COMMERCIAL_DOCS = [
  "identity",
  "driver_license",
  "vehicle_registration",
  "insurance",
  "criminal_record",
  "commercial_license",
] as const;

export const CHAUFFEUR_SERVICE_GATE = {
  /** Modül canlı hizmete açıldı mı? Hukuk onayı olmadan false kalır. */
  live: process.env.CHAUFFEUR_SERVICE_LIVE === "true",
  label: "Pilot — hukuk onayı bekliyor",
};

export type RideStatus =
  | "REQUESTED"
  | "MATCHING"
  | "DRIVER_ASSIGNED"
  | "DRIVER_EN_ROUTE"
  | "DRIVER_ARRIVED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED_BY_PASSENGER"
  | "CANCELLED_BY_DRIVER"
  | "DRIVER_NO_SHOW"
  | "SAFETY_INCIDENT";

export const RIDE_STATUS_LABEL: Record<RideStatus, string> = {
  REQUESTED: "Talep alındı",
  MATCHING: "Sürücü aranıyor",
  DRIVER_ASSIGNED: "Sürücü atandı",
  DRIVER_EN_ROUTE: "Sürücü yolda",
  DRIVER_ARRIVED: "Sürücü buluşma noktasında",
  IN_PROGRESS: "Yolculuk sürüyor",
  COMPLETED: "Tamamlandı",
  CANCELLED_BY_PASSENGER: "Yolcu iptal etti",
  CANCELLED_BY_DRIVER: "Sürücü iptal etti",
  DRIVER_NO_SHOW: "Sürücü gelmedi",
  SAFETY_INCIDENT: "Güvenlik olayı",
};

/** Durum geçiş izin matrisi — sunucuda zorunlu. */
export const RIDE_TRANSITIONS: Record<RideStatus, RideStatus[]> = {
  REQUESTED: ["MATCHING", "CANCELLED_BY_PASSENGER"],
  MATCHING: ["DRIVER_ASSIGNED", "CANCELLED_BY_PASSENGER", "DRIVER_NO_SHOW"],
  DRIVER_ASSIGNED: ["DRIVER_EN_ROUTE", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "SAFETY_INCIDENT"],
  DRIVER_EN_ROUTE: ["DRIVER_ARRIVED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW", "SAFETY_INCIDENT"],
  DRIVER_ARRIVED: ["IN_PROGRESS", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW", "SAFETY_INCIDENT"],
  IN_PROGRESS: ["COMPLETED", "SAFETY_INCIDENT"],
  COMPLETED: [],
  CANCELLED_BY_PASSENGER: [],
  CANCELLED_BY_DRIVER: [],
  DRIVER_NO_SHOW: [],
  SAFETY_INCIDENT: ["IN_PROGRESS", "CANCELLED_BY_PASSENGER", "COMPLETED"],
};

export function isRideStatus(value: string): value is RideStatus {
  return Object.prototype.hasOwnProperty.call(RIDE_STATUS_LABEL, value);
}

export function canTransitionRide(from: string, to: string): boolean {
  if (!isRideStatus(from) || !isRideStatus(to)) return false;
  return RIDE_TRANSITIONS[from].includes(to);
}

/* -------------------------------- Ücret ---------------------------------- */

export type FareBreakdown = { label: string; kurus: number }[];

export type Fare = {
  tariffCode: string;
  totalKurus: number;
  minApplied: boolean;
  nightApplied: boolean;
  surgeApplied: boolean;
  breakdown: FareBreakdown;
};

/** Gece tarifesi 22:00 – 06:00. */
export function isNightHours(at: Date = new Date()): boolean {
  const h = at.getHours();
  return h >= 22 || h < 6;
}

export async function getActiveTariff(code = "suruculu_standart") {
  const rows = await db.select().from(chauffeurTariffs).where(eq(chauffeurTariffs.code, code)).limit(1);
  return rows[0] ?? null;
}

/**
 * Ücret YALNIZCA sunucuda hesaplanır. İstemciden gelen tutar yok sayılır.
 */
export async function calculateFare(args: {
  distanceKm: number;
  durationMin: number;
  tariffCode?: string;
  at?: Date;
  isAirport?: boolean;
}): Promise<Fare | null> {
  const tariff = await getActiveTariff(args.tariffCode ?? "suruculu_standart");
  if (!tariff) return null;

  const km = Math.min(Math.max(Number(args.distanceKm) || 1, 0.5), 200);
  const min = Math.min(Math.max(Number(args.durationMin) || 5, 1), 400);

  const distancePart = Math.round(km * tariff.perKmKurus);
  const durationPart = Math.round(min * tariff.perMinKurus);
  const night = isNightHours(args.at ?? new Date());
  const nightPart = night ? Math.round(((tariff.baseKurus + distancePart + durationPart) * tariff.nightSurchargePercent) / 100) : 0;
  const airportPart = args.isAirport ? tariff.airportSurchargeKurus : 0;
  const surge = tariff.surgeMultiplier > 1 ? tariff.surgeMultiplier : 1;

  const raw = Math.round((tariff.baseKurus + distancePart + durationPart + nightPart + airportPart) * surge);
  const totalKurus = Math.max(raw, tariff.minFareKurus);

  const breakdown: FareBreakdown = [
    { label: "Açılış", kurus: tariff.baseKurus },
    { label: `Mesafe (${km.toFixed(1)} km)`, kurus: distancePart },
    { label: `Süre (${Math.round(min)} dk)`, kurus: durationPart },
  ];
  if (nightPart > 0) breakdown.push({ label: `Gece tarifesi (%${tariff.nightSurchargePercent})`, kurus: nightPart });
  if (airportPart > 0) breakdown.push({ label: "Havalimanı", kurus: airportPart });
  if (surge > 1) breakdown.push({ label: `Yoğunluk çarpanı (${surge.toFixed(2)}x)`, kurus: 0 });
  if (totalKurus > raw) breakdown.push({ label: "Asgari ücret uygulandı", kurus: totalKurus - raw });

  return {
    tariffCode: tariff.code,
    totalKurus,
    minApplied: totalKurus > raw,
    nightApplied: night,
    surgeApplied: surge > 1,
    breakdown,
  };
}

/* ------------------------------ Eşleştirme -------------------------------- */

export function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const lat1 = (aLat * Math.PI) / 180;
  const lat2 = (bLat * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export type Candidate = {
  chauffeurId: number;
  fullName: string;
  distanceKm: number;
  etaSec: number;
  score: number;
  rating: number | null;
  acceptanceRate: number;
  vehicle: { plate: string; make: string; model: string; color: string; vehicleType: string; seatCount: number };
  isDemo: boolean;
};

/**
 * Aday sürücü sıralaması.
 * Kriterler: mesafe, araç tipi uyumu, puan, kabul oranı, erişilebilirlik.
 * Cinsiyet bazlı filtre YOKTUR — ayrımcılık mevzuatı riski.
 */
export async function findCandidates(args: {
  pickupLat: number | null;
  pickupLng: number | null;
  pickupDistrict: string;
  vehicleTypeRequested: string;
  accessibleNeeded?: boolean;
  limit?: number;
}): Promise<Candidate[]> {
  const rows = await db.select().from(chauffeurProfiles).where(
    and(
      eq(chauffeurProfiles.availability, "online_idle"),
      eq(chauffeurProfiles.isVerified, true),
      // Ticari yolcu taşıma belgesi doğrulanmamış sürücü teklif alamaz.
      eq(chauffeurProfiles.commercialDocsVerified, true),
      isNull(chauffeurProfiles.suspendedUntil),
    ),
  );

  const candidates: Candidate[] = [];
  for (const profile of rows) {
    if (profile.suspendedUntil && profile.suspendedUntil.getTime() > Date.now()) continue;

    const vehicles = await db
      .select()
      .from(chauffeurVehicles)
      .where(and(eq(chauffeurVehicles.chauffeurId, profile.id), eq(chauffeurVehicles.isActive, true)))
      .limit(1);
    const vehicle = vehicles[0];
    if (!vehicle || !vehicle.documentsVerified) continue;

    // Özel araç (platform dışı sahiplik) yalnızca hukuk bayrağı açıksa eşleşir.
    if (vehicle.ownership === "private" && !ALLOW_PRIVATE_CAR_MATCHING) continue;

    if (args.accessibleNeeded && vehicle.vehicleType !== "accessible") continue;

    const typeMatch = vehicle.vehicleType === args.vehicleTypeRequested || args.vehicleTypeRequested === "standard";
    const lat = profile.lastLat ?? (args.pickupLat ?? 41.008);
    const lng = profile.lastLng ?? (args.pickupLng ?? 28.98);
    const distanceKm =
      args.pickupLat !== null && args.pickupLng !== null
        ? haversineKm(args.pickupLat, args.pickupLng, lat, lng)
        : profile.city === "İstanbul"
          ? 3.5
          : 25;

    const totalOffers = profile.acceptedOffers + profile.declinedOffers;
    const acceptanceRate = totalOffers > 0 ? profile.acceptedOffers / totalOffers : 1;
    const rating = profile.ratingCount > 0 ? profile.ratingSum / profile.ratingCount : null;

    // Skor: mesafe baskın, araç uyumu ve geçmiş performans düzeltici.
    const score =
      Math.max(0, 100 - distanceKm * 12) +
      (typeMatch ? 15 : 0) +
      (rating === null ? 5 : rating * 4) +
      acceptanceRate * 15;

    candidates.push({
      chauffeurId: profile.id,
      fullName: profile.fullName,
      distanceKm: Math.round(distanceKm * 10) / 10,
      etaSec: Math.max(60, Math.round(distanceKm * 150)),
      score: Math.round(score),
      rating,
      acceptanceRate: Math.round(acceptanceRate * 100),
      vehicle: {
        plate: vehicle.plate,
        make: vehicle.make,
        model: vehicle.model,
        color: vehicle.color,
        vehicleType: vehicle.vehicleType,
        seatCount: vehicle.seatCount,
      },
      isDemo: profile.isDemo,
    });
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates.slice(0, args.limit ?? 3);
}

/* --------------------------------- OTP ------------------------------------ */

export async function issuePickupOtp(rideId: number): Promise<string> {
  const { code, hash } = newOtp();
  await db.update(passengerRides).set({ pickupOtpHash: hash }).where(eq(passengerRides.id, rideId));
  // Gerçek dağıtımda SMS kuyruğuna yazılır; sağlayıcı yokken loglanır.
  console.info(`[suruculu-otp] ride=${rideId} kod=${code}`);
  return code;
}

export async function verifyPickupOtp(rideId: number, code: string): Promise<boolean> {
  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, rideId)).limit(1);
  if (!ride || !ride.pickupOtpHash) return false;
  const ok = verifyOtp(code.replace(/\D/g, ""), ride.pickupOtpHash);
  if (ok) await db.update(passengerRides).set({ otpVerifiedAt: new Date() }).where(eq(passengerRides.id, rideId));
  return ok;
}

/* -------------------------------- Olaylar ---------------------------------- */

export async function logRideEvent(args: {
  rideId: number;
  eventType: string;
  actor?: string;
  lat?: number | null;
  lng?: number | null;
  note?: string;
}) {
  await db.insert(passengerRideEvents).values({
    rideId: args.rideId,
    eventType: args.eventType,
    actor: args.actor ?? "system",
    lat: args.lat ?? null,
    lng: args.lng ?? null,
    note: (args.note ?? "").slice(0, 300),
  });
}

/* ------------------------------ Tamamlama ---------------------------------- */

/**
 * Yolculuk kapanışı: gerçek mesafe/süre ile ücret YENİDEN hesaplanır,
 * komisyon çift taraflı kayıtla düşülür, sürücü hakedişi cüzdanına geçer.
 * Kayıt silinmez; hatalı işlem ters kayıtla düzeltilir.
 */
export async function completeRide(args: {
  rideId: number;
  actualDistanceKm: number;
  actualDurationMin: number;
  actorId: number;
  actorRole: string;
}) {
  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, args.rideId)).limit(1);
  if (!ride) return { ok: false as const, error: "Yolculuk bulunamadı" };
  if (!canTransitionRide(ride.status, "COMPLETED")) {
    return { ok: false as const, error: `Bu durumdan tamamlanamaz: ${RIDE_STATUS_LABEL[ride.status as RideStatus]}` };
  }
  if (!ride.otpVerifiedAt) {
    return { ok: false as const, error: "Buluşma OTP'si doğrulanmadan yolculuk başlatılamaz veya bitirilemez." };
  }

  const tariff = await getActiveTariff(ride.tariffCode);
  const finalFare = await calculateFare({
    distanceKm: args.actualDistanceKm,
    durationMin: args.actualDurationMin,
    tariffCode: ride.tariffCode,
  });
  if (!tariff || !finalFare) return { ok: false as const, error: "Tarife bulunamadı" };

  const commissionKurus = Math.round((finalFare.totalKurus * tariff.commissionPercent) / 100);
  const driverNetKurus = finalFare.totalKurus - commissionKurus;
  const now = new Date();

  const [updated] = await db
    .update(passengerRides)
    .set({
      status: "COMPLETED",
      finalFareKurus: finalFare.totalKurus,
      commissionKurus,
      distanceKm: args.actualDistanceKm,
      durationMin: args.actualDurationMin,
      dropoffAt: now,
      paymentStatus: "odendi",
    })
    .where(eq(passengerRides.id, args.rideId))
    .returning();

  await logRideEvent({
    rideId: args.rideId,
    eventType: "COMPLETED",
    actor: args.actorRole,
    note: `Gerçek ${args.actualDistanceKm.toFixed(1)} km / ${args.actualDurationMin} dk`,
  });

  // Ledger: yolcu borcu → platform geliri; platform komisyonu → sürücü hakedişi.
  if (ride.chauffeurId) {
    const driverWallet = await ensureWallet("chauffeur", ride.chauffeurId);
    const [systemWallet] = await db.select().from(wallets).where(eq(wallets.ownerKind, "system")).limit(1);
    if (systemWallet) {
      try {
        await postLedger({
          kind: "ride_charge",
          idempotencyKey: `hail_${ride.id}_fare`,
          refKind: "passenger_ride",
          refId: ride.id,
          note: `${ride.code} · yolculuk ücreti`,
          allowOverdraft: true,
          postings: [
            { walletId: systemWallet.id, side: "debit", amountKurus: finalFare.totalKurus, reason: "yolculuk_tahsilati" },
            { walletId: systemWallet.id, side: "credit", amountKurus: finalFare.totalKurus, reason: "yolculuk_geliri" },
          ],
        });
        await postLedger({
          kind: "courier_payout",
          idempotencyKey: `hail_${ride.id}_driver_net`,
          refKind: "passenger_ride",
          refId: ride.id,
          note: `${ride.code} · sürücü hakedişi (komisyon %${tariff.commissionPercent} düşüldü)`,
          postings: [
            { walletId: systemWallet.id, side: "debit", amountKurus: driverNetKurus, reason: "surucu_hakedis_odeme" },
            { walletId: driverWallet.id, side: "credit", amountKurus: driverNetKurus, reason: "surucu_hakedis" },
          ],
        });
      } catch {
        // Ledger yazılamazsa yolculuk COMPLETED kalır; mutabakat ekranı farkı gösterir.
      }

      await db
        .update(chauffeurProfiles)
        .set({
          totalTrips: sql`${chauffeurProfiles.totalTrips} + 1`,
          availability: "online_idle",
        })
        .where(eq(chauffeurProfiles.id, ride.chauffeurId));
    }
  }

  await writeAudit({
    actorId: args.actorId,
    actorRole: args.actorRole,
    action: "suruculu_yolculuk_tamamlandi",
    entity: "passenger_ride",
    entityId: String(ride.id),
    meta: { finalFareKurus: finalFare.totalKurus, commissionKurus, quotedKurus: ride.quotedFareKurus },
  });

  return {
    ok: true as const,
    ride: updated,
    quotedKurus: ride.quotedFareKurus,
    finalKurus: finalFare.totalKurus,
    differenceKurus: finalFare.totalKurus - ride.quotedFareKurus,
    commissionKurus,
    driverNetKurus,
    breakdown: finalFare.breakdown,
  };
}

/* -------------------------------- Teklifler -------------------------------- */

export const OFFER_TTL_SEC = 30;

export async function sendOffers(rideId: number, candidates: Candidate[]) {
  const now = Date.now();
  for (const candidate of candidates) {
    await db.insert(chauffeurOffers).values({
      rideId,
      chauffeurId: candidate.chauffeurId,
      quotedEtaSec: candidate.etaSec,
      status: "sent",
      expiresAt: new Date(now + OFFER_TTL_SEC * 1000),
    });
  }
  await db.update(passengerRides).set({ status: "MATCHING" }).where(eq(passengerRides.id, rideId));
  await logRideEvent({ rideId, eventType: "MATCHING", note: `${candidates.length} sürücüye teklif gönderildi` });
}

/** Süresi dolan teklifleri kapatır. */
export async function expireStaleOffers(rideId: number) {
  await db
    .update(chauffeurOffers)
    .set({ status: "expired" })
    .where(
      and(
        eq(chauffeurOffers.rideId, rideId),
        eq(chauffeurOffers.status, "sent"),
        sql`${chauffeurOffers.expiresAt} < now()`,
      ),
    );
  const remaining = await db
    .select({ id: chauffeurOffers.id })
    .from(chauffeurOffers)
    .where(and(eq(chauffeurOffers.rideId, rideId), eq(chauffeurOffers.status, "sent")));
  if (remaining.length === 0) {
    const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, rideId)).limit(1);
    if (ride && ride.status === "MATCHING") {
      await db.update(passengerRides).set({ status: "DRIVER_NO_SHOW" }).where(eq(passengerRides.id, rideId));
      await logRideEvent({ rideId, eventType: "DRIVER_NO_SHOW", note: "Teklif süresi doldu, sürücü kabul etmedi" });
    }
  }
  return remaining.length;
}

export async function openOffersFor(chauffeurId: number) {
  return db
    .select()
    .from(chauffeurOffers)
    .where(and(eq(chauffeurOffers.chauffeurId, chauffeurId), inArray(chauffeurOffers.status, ["sent"])));
}
