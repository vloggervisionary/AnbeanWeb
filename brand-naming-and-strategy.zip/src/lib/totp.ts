import crypto from "node:crypto";

/**
 * TOTP (RFC 6238) — bağımlılık yok, node:crypto ile.
 * Yönetici hesaplarında iki aşamalı doğrulama desteği.
 *
 * Sır kurulduktan sonra arayüzde BİR KEZ gösterilir; sonrasında yalnızca
 * "etkin" durumu görünür. Loglanmaz, API yanıtlarına konmaz.
 */
const PERIOD = 30;
const DIGITS = 6;
const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export function generateSecret(): string {
  const bytes = crypto.randomBytes(20);
  let out = "";
  let bits = 0;
  let value = 0;
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += ALPHABET[(value << (5 - bits)) & 31];
  return out;
}

function base32Decode(input: string): Buffer {
  const clean = input.toUpperCase().replace(/=+$/g, "").replace(/\s/g, "");
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const char of clean) {
    const idx = ALPHABET.indexOf(char);
    if (idx === -1) throw new Error("Geçersiz base32 karakter");
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function totpAt(secret: string, time: number = Date.now()): string {
  const counter = Math.floor(time / 1000 / PERIOD);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", base32Decode(secret)).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
  return String(code % 10 ** DIGITS).padStart(DIGITS, "0");
}

/** Saat kaymalarına tolerans: bir önceki ve bir sonraki pencere de kabul edilir. */
export function verifyTotp(secret: string, code: string, windowSteps = 1): boolean {
  const clean = code.replace(/\D/g, "");
  if (clean.length !== DIGITS) return false;
  const now = Date.now();
  for (let step = -windowSteps; step <= windowSteps; step += 1) {
    if (totpAt(secret, now + step * PERIOD * 1000) === clean) return true;
  }
  return false;
}

export function otpauthUrl({
  secret,
  account,
  issuer = "Anbean",
}: {
  secret: string;
  account: string;
  issuer?: string;
}): string {
  const label = `${encodeURIComponent(issuer)}:${encodeURIComponent(account)}`;
  return `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=${DIGITS}&period=${PERIOD}`;
}
