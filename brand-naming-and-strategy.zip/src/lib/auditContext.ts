import { headers } from "next/headers";

/**
 * Denetim bağlamı: IP ve kullanıcı ajanı.
 * writeAudit çağrılarına otomatik eklenir; PII loglanmaz.
 */
export async function requestContext(): Promise<{ ip: string; userAgent: string }> {
  try {
    const head = await headers();
    return {
      ip: head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "",
      userAgent: (head.get("user-agent") ?? "").slice(0, 200),
    };
  } catch {
    return { ip: "", userAgent: "" };
  }
}

/**
 * CSV üretimi.
 * - Hücreler RFC 4180'e göre kaçışlanır (formül enjeksiyonu için = + - @ öneki kesilir).
 * - Dışa aktarma her zaman yetki + gerekçe + denetim kaydı gerektirir (çağıran yerde).
 */
export function toCsv(rows: Record<string, unknown>[], columns?: string[]): string {
  if (rows.length === 0) return "";
  const keys = columns ?? Object.keys(rows[0]);
  const escape = (value: unknown): string => {
    if (value === null || value === undefined) return "";
    let text = value instanceof Date ? value.toISOString() : String(value);
    if (/^[=+\-@]/.test(text)) text = `'${text}`;
    return /[",\n;]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const lines = [keys.join(",")];
  for (const row of rows) lines.push(keys.map((key) => escape(row[key])).join(","));
  return lines.join("\n");
}

export function csvResponse(filename: string, csv: string): Response {
  return new Response(`\uFEFF${csv}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
