"use client";

import { useState } from "react";

export default function ChauffeurApplyForm() {
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    city: "İstanbul",
    vehicleType: "standard",
    ownership: "private",
    hasCommercialLicense: false,
    experienceYears: 0,
    plate: "",
    note: "",
  });
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [documents, setDocuments] = useState<string[]>([]);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("busy");
    const res = await fetch("/api/chauffeur/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = (await res.json().catch(() => ({}))) as {
      error?: string;
      notice?: string;
      requiredDocuments?: string[];
    };
    setState(res.ok ? "done" : "error");
    setMessage(res.ok ? (data.notice ?? "Başvurun alındı.") : (data.error ?? "Başvuru gönderilemedi."));
    if (data.requiredDocuments) setDocuments(data.requiredDocuments);
  }

  if (state === "done") {
    return (
      <div className="rounded-lg border border-st-delivered/40 bg-st-delivered/10 p-6">
        <h2 className="font-display text-lg font-semibold text-white">Başvuru alındı</h2>
        <p className="mt-2 text-sm text-slate-300">{message}</p>
        {documents.length > 0 ? (
          <>
            <p className="mt-4 text-xs uppercase tracking-[0.12em] text-slate-400">Gereken belgeler</p>
            <ul className="mt-2 space-y-1 text-sm text-slate-300">
              {documents.map((doc) => (
                <li key={doc}>· {doc.replaceAll("_", " ")}</li>
              ))}
            </ul>
          </>
        ) : null}
        <p className="mt-4 text-xs text-slate-400">
          Giriş yaptıysan belge durumunu sürücü panelinden izleyebilirsin.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-lg border border-white/10 bg-white/3 p-6">
      <h2 className="font-display text-lg font-semibold text-white">Sürücü başvurusu</h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <Field id="ca-name" label="Ad soyad">
          <input
            id="ca-name"
            value={form.fullName}
            onChange={(e) => set("fullName", e.target.value)}
            className="input-dark"
            autoComplete="name"
            required
            minLength={3}
          />
        </Field>
        <Field id="ca-phone" label="Telefon">
          <input
            id="ca-phone"
            value={form.phone}
            onChange={(e) => set("phone", e.target.value)}
            className="input-dark"
            autoComplete="tel"
            inputMode="tel"
            required
          />
        </Field>
        <Field id="ca-city" label="Şehir">
          <select id="ca-city" value={form.city} onChange={(e) => set("city", e.target.value)} className="input-dark">
            {["İstanbul", "Ankara", "İzmir", "Bursa", "Antalya"].map((city) => (
              <option key={city} value={city} className="bg-[#0b1220]">
                {city}
              </option>
            ))}
          </select>
        </Field>
        <Field id="ca-plate" label="Plaka">
          <input
            id="ca-plate"
            value={form.plate}
            onChange={(e) => set("plate", e.target.value.toUpperCase())}
            className="input-dark font-mono"
            placeholder="34 ABC 111"
          />
        </Field>
        <Field id="ca-type" label="Araç tipi">
          <select
            id="ca-type"
            value={form.vehicleType}
            onChange={(e) => set("vehicleType", e.target.value)}
            className="input-dark"
          >
            {[
              ["standard", "Standart (sedan)"],
              ["comfort", "Konfor"],
              ["accessible", "Erişilebilir"],
              ["van", "Van"],
            ].map(([value, label]) => (
              <option key={value} value={value} className="bg-[#0b1220]">
                {label}
              </option>
            ))}
          </select>
        </Field>
        <Field id="ca-ownership" label="Araç sahipliği">
          <select
            id="ca-ownership"
            value={form.ownership}
            onChange={(e) => set("ownership", e.target.value)}
            className="input-dark"
          >
            <option value="private" className="bg-[#0b1220]">
              Kendi aracım
            </option>
            <option value="platform" className="bg-[#0b1220]">
              Platform filosu
            </option>
          </select>
        </Field>
        <Field id="ca-exp" label="Deneyim (yıl)">
          <input
            id="ca-exp"
            type="number"
            min={0}
            max={60}
            value={form.experienceYears}
            onChange={(e) => set("experienceYears", Number(e.target.value))}
            className="input-dark"
          />
        </Field>
        <div className="flex items-end">
          <label className="flex items-center gap-3 pb-2 text-sm text-slate-300">
            <input
              type="checkbox"
              checked={form.hasCommercialLicense}
              onChange={(e) => set("hasCommercialLicense", e.target.checked)}
              className="h-4 w-4 accent-[var(--accent)]"
            />
            Ticari yolcu taşıma belgem var
          </label>
        </div>
      </div>

      <Field id="ca-note" label="Not" className="mt-4">
        <textarea
          id="ca-note"
          rows={3}
          value={form.note}
          onChange={(e) => set("note", e.target.value)}
          className="input-dark"
          maxLength={500}
        />
      </Field>

      {state === "error" ? (
        <p role="alert" className="mt-3 text-sm text-st-risk">
          {message}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={state === "busy" || !form.hasCommercialLicense}
        className="mt-5 w-full rounded-md bg-accent px-5 py-3 text-sm font-semibold text-[#0B1220] transition hover:bg-accent-soft disabled:opacity-50 sm:w-auto"
      >
        {state === "busy" ? "Gönderiliyor…" : "Başvuruyu gönder"}
      </button>

      {!form.hasCommercialLicense ? (
        <p className="mt-3 text-xs text-st-waiting">
          Ticari yolcu taşıma belgesi olmadan başvuru tamamlanamaz; bu belge hizmetin yasal ön koşuludur.
        </p>
      ) : null}

      <p className="mt-4 text-[11px] text-slate-500">
        Telefon numaran maskelenerek saklanır. Başvuru verileri yalnızca değerlendirme amacıyla işlenir; ayrıntı için
        kurye/sürücü adayı aydınlatma metnine bak.
      </p>
    </form>
  );
}

function Field({
  id,
  label,
  children,
  className = "",
}: {
  id: string;
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
        {label}
      </label>
      <div className="mt-2">{children}</div>
    </div>
  );
}
