"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const DOC_LABEL: Record<string, string> = {
  identity: "Kimlik",
  driver_license: "Ehliyet",
  vehicle_registration: "Araç ruhsatı",
  insurance: "Sigorta",
  criminal_record: "Adli sicil",
  commercial_license: "Ticari taşıma belgesi",
};

/** Belge onay/red. Tüm ticari belgeler onaylanınca sürücü aktif olur. */
export default function DocumentVerify({
  chauffeurId,
  documents,
  plates,
}: {
  chauffeurId: number;
  documents: { docType: string; status: string }[];
  plates: string[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [plate, setPlate] = useState(plates[0] ?? "");

  async function decide(docType: string, decision: "approved" | "rejected") {
    setBusy(`${docType}-${decision}`);
    setError("");
    const res = await fetch(`/api/admin/chauffeur/${chauffeurId}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ docType, decision, vehiclePlate: plate || undefined }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; fullyVerified?: boolean; missing?: string[] };
    setBusy("");
    if (!res.ok) {
      setError(data.error ?? "İşlem başarısız.");
      return;
    }
    router.refresh();
    if (data.fullyVerified) setError("");
  }

  return (
    <div className="mt-3 rounded-md bg-slate-50 p-3">
      <label className="text-[11px] uppercase tracking-[0.1em] text-slate-500" htmlFor={`plate-${chauffeurId}`}>
        Araç plakası (onayla birlikte doğrulanır)
      </label>
      <select
        id={`plate-${chauffeurId}`}
        value={plate}
        onChange={(e) => setPlate(e.target.value)}
        className="input-light mt-1 py-2 text-sm"
      >
        {plates.length === 0 ? <option value="">kayıtlı araç yok</option> : null}
        {plates.map((item) => (
          <option key={item} value={item}>
            {item}
          </option>
        ))}
      </select>

      <ul className="mt-3 space-y-2">
        {documents.map((doc) => (
          <li key={doc.docType} className="flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="text-slate-700">
              {DOC_LABEL[doc.docType] ?? doc.docType}
              <span className="ml-2 text-[11px] text-slate-500">{doc.status}</span>
            </span>
            <span className="flex gap-2">
              <button
                type="button"
                disabled={busy !== "" || doc.status === "approved"}
                onClick={() => decide(doc.docType, "approved")}
                className="rounded-md border border-st-delivered/50 px-2.5 py-1 text-[11px] font-semibold text-green-700 disabled:opacity-40"
              >
                {busy === `${doc.docType}-approved` ? "…" : "Onayla"}
              </button>
              <button
                type="button"
                disabled={busy !== "" || doc.status === "rejected"}
                onClick={() => decide(doc.docType, "rejected")}
                className="rounded-md border border-st-risk/50 px-2.5 py-1 text-[11px] font-semibold text-st-risk disabled:opacity-40"
              >
                {busy === `${doc.docType}-rejected` ? "…" : "Reddet"}
              </button>
            </span>
          </li>
        ))}
      </ul>
      {error ? <p className="mt-2 text-[11px] text-st-risk">{error}</p> : null}
      <p className="mt-3 text-[11px] text-slate-500">
        Dosya sağlayıcısı yok: onay meta veri üzerinden verilir. Tüm ticari belgeler onaylanınca sürücü doğrulanmış
        sayılır ve rolü otomatik yükseltilir (denetime yazılır).
      </p>
    </div>
  );
}
