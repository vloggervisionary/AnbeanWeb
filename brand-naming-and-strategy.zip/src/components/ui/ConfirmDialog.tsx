"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Kritik işlem onayı: askıya alma, arşivleme, finansal düzeltme, sürüm geri yükleme.
 * Gerekçe alanı zorunlu tutulabilir — denetim kaydına yazılır.
 * Esc ile kapanır, odak pencereye alınır, role=alertdialog.
 */
type Props = {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  tone?: "danger" | "warning" | "neutral";
  requireReason?: boolean;
  reasonLabel?: string;
  busy?: boolean;
  onConfirm: (reason: string) => void;
  onCancel: () => void;
};

/**
 * Açıkken iç bileşen mount edilir; her açılışta gerekçe alanı taze başlar.
 * Böylece efekt gövdesinde setState gerekmez (kaskad render yok).
 */
export default function ConfirmDialog(props: Props) {
  if (!props.open) return null;
  return <ConfirmDialogInner key={`${props.title}-${props.confirmLabel}`} {...props} />;
}

function ConfirmDialogInner({
  title,
  body,
  confirmLabel,
  tone = "danger",
  requireReason = false,
  reasonLabel = "Gerekçe",
  busy = false,
  onConfirm,
  onCancel,
}: Props) {
  const [reason, setReason] = useState("");
  const confirmRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    confirmRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  const toneClass =
    tone === "danger"
      ? "bg-st-risk text-white"
      : tone === "warning"
        ? "bg-st-waiting text-[#0B1220]"
        : "bg-accent text-[#0B1220]";
  const canConfirm = !busy && (!requireReason || reason.trim().length >= 5);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-[#0B1220]/70" onClick={onCancel} aria-hidden />
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirm-title"
        aria-describedby="confirm-body"
        className="relative w-full max-w-md rounded-lg border border-slate-200 bg-white p-6 shadow-xl"
      >
        <h2 id="confirm-title" className="font-display text-lg font-bold text-[#0B1220]">
          {title}
        </h2>
        <p id="confirm-body" className="mt-2 text-sm text-slate-600">
          {body}
        </p>
        {requireReason ? (
          <div className="mt-4">
            <label htmlFor="confirm-reason" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
              {reasonLabel} (zorunlu, denetim kaydına yazılır)
            </label>
            <textarea
              id="confirm-reason"
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="input-light mt-2"
              maxLength={300}
            />
            <p className="mt-1 text-[11px] text-slate-500">En az 5 karakter · {reason.length}/300</p>
          </div>
        ) : null}
        <div className="mt-5 flex gap-2">
          <button
            type="button"
            ref={confirmRef}
            disabled={!canConfirm}
            onClick={() => onConfirm(reason.trim())}
            className={`flex-1 rounded-md px-4 py-3 text-sm font-semibold transition hover:opacity-90 disabled:opacity-40 ${toneClass}`}
          >
            {busy ? "İşleniyor…" : confirmLabel}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 rounded-md border border-slate-300 px-4 py-3 text-sm text-slate-700 transition hover:border-slate-500"
          >
            Vazgeç
          </button>
        </div>
      </div>
    </div>
  );
}
