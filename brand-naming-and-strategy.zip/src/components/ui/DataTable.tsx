"use client";

import { useMemo, useState } from "react";
import { ChevronDown, ChevronUp, Search } from "lucide-react";

export type Column<T> = {
  key: string;
  header: string;
  /** Sıralama için ham değer döndürür. */
  value: (row: T) => string | number | null;
  render?: (row: T) => React.ReactNode;
  className?: string;
};

const PAGE_SIZES = [10, 25, 50];

/**
 * Sunucu verisiyle çalışan tablo: arama, sıralama, sayfalama.
 * Dar ekranda kart görünümüne döner (tablo taşmaz).
 * Veri zaten sunucudan filtrelenmiş gelebilir; buradaki arama ek katmandır.
 */
export default function DataTable<T>({
  rows,
  columns,
  searchKeys,
  emptyText = "Kayıt yok.",
  initialSort,
  pageSize: initialPageSize = 10,
  rowKey,
  onRowClick,
}: {
  rows: T[];
  columns: Column<T>[];
  searchKeys: (keyof T)[];
  emptyText?: string;
  initialSort?: { key: string; dir: "asc" | "desc" };
  pageSize?: number;
  rowKey: (row: T) => string | number;
  onRowClick?: (row: T) => void;
}) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<{ key: string; dir: "asc" | "desc" } | null>(initialSort ?? null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(initialPageSize);

  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase("tr-TR");
    if (!q) return rows;
    return rows.filter((row) =>
      searchKeys.some((key) => String(row[key] ?? "").toLocaleLowerCase("tr-TR").includes(q)),
    );
  }, [rows, query, searchKeys]);

  const sorted = useMemo(() => {
    if (!sort) return filtered;
    const column = columns.find((c) => c.key === sort.key);
    if (!column) return filtered;
    return [...filtered].sort((a, b) => {
      const av = column.value(a);
      const bv = column.value(b);
      if (av === bv) return 0;
      if (av === null) return 1;
      if (bv === null) return -1;
      const cmp = typeof av === "number" && typeof bv === "number" ? av - bv : String(av).localeCompare(String(bv), "tr");
      return sort.dir === "asc" ? cmp : -cmp;
    });
  }, [filtered, sort, columns]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const current = Math.min(page, pageCount - 1);
  const slice = sorted.slice(current * pageSize, current * pageSize + pageSize);

  function toggleSort(key: string) {
    setSort((prev) => (prev?.key === key ? { key, dir: prev.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }));
    setPage(0);
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-52">
          <Search size={15} aria-hidden className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400" />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
            placeholder="Ara…"
            aria-label="Tabloda ara"
            className="input-light py-2 pl-9 text-sm"
          />
        </div>
        <label className="flex items-center gap-2 text-xs text-slate-500">
          Sayfa başına
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(0);
            }}
            className="input-light w-20 py-1.5 text-xs"
          >
            {PAGE_SIZES.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </label>
        <span className="text-xs text-slate-500" role="status">
          {sorted.length} kayıt
        </span>
      </div>

      {/* Masaüstü: tablo */}
      <div className="hidden overflow-x-auto rounded-lg border border-slate-200 md:block">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-[11px] uppercase tracking-[0.08em] text-slate-500">
            <tr>
              {columns.map((column) => (
                <th key={column.key} scope="col" className="px-4 py-3">
                  <button
                    type="button"
                    onClick={() => toggleSort(column.key)}
                    className="inline-flex items-center gap-1 font-semibold transition hover:text-slate-800"
                    aria-label={`${column.header} sırala`}
                  >
                    {column.header}
                    {sort?.key === column.key ? (
                      sort.dir === "asc" ? (
                        <ChevronUp size={12} aria-hidden />
                      ) : (
                        <ChevronDown size={12} aria-hidden />
                      )
                    ) : null}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {slice.map((row) => (
              <tr
                key={rowKey(row)}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={onRowClick ? "cursor-pointer transition hover:bg-slate-50" : "transition hover:bg-slate-50"}
              >
                {columns.map((column) => (
                  <td key={column.key} className={`px-4 py-3 ${column.className ?? ""}`}>
                    {column.render ? column.render(row) : column.value(row)}
                  </td>
                ))}
              </tr>
            ))}
            {slice.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="px-4 py-10 text-center text-slate-500">
                  {emptyText}
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {/* Dar ekran: kart görünümü */}
      <ul className="space-y-2 md:hidden">
        {slice.map((row) => (
          <li key={rowKey(row)}>
            <button
              type="button"
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className="w-full rounded-lg border border-slate-200 bg-white p-4 text-left"
            >
              {columns.map((column) => (
                <p key={column.key} className="flex justify-between gap-3 py-0.5 text-sm">
                  <span className="text-slate-500">{column.header}</span>
                  <span className="text-right text-slate-800">{column.render ? column.render(row) : column.value(row)}</span>
                </p>
              ))}
            </button>
          </li>
        ))}
        {slice.length === 0 ? <li className="py-8 text-center text-sm text-slate-500">{emptyText}</li> : null}
      </ul>

      {pageCount > 1 ? (
        <div className="mt-3 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={current === 0}
            className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500 disabled:opacity-40"
          >
            Önceki
          </button>
          <span className="text-xs text-slate-500">
            {current + 1} / {pageCount}
          </span>
          <button
            type="button"
            onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
            disabled={current >= pageCount - 1}
            className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500 disabled:opacity-40"
          >
            Sonraki
          </button>
        </div>
      ) : null}
    </div>
  );
}
