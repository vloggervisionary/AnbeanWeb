"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ShieldAlert } from "lucide-react";

const DISTRICTS = ["Kadıköy", "Beşiktaş", "Şişli", "Üsküdar", "Bakırköy", "Maltepe", "Beylikdüzü", "Pendik"];
const SERVICES = [
  { value: "standart", label: "Standart", note: "4 kişilik, sedan" },
  { value: "konfor", label: "Konfor", note: "geniş iç hacim" },
  { value: "erisilebilir", label: "Erişilebilir", note: "tekerlekli sandalye uyumlu" },
];

function tl(kurus: number) {
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
}

type Quote = {
  totalKurus: number;
  breakdown: { label: string; kurus: number }[];
  nightApplied: boolean;
  surgeApplied: boolean;
  serviceLive: boolean;
  serviceLabel: string;
  disclaimer: string;
};

/**
 * Sürücülü yolculuk talebi.
 * Ücret YALNIZCA sunucudan gelir; istemci tutar göndermez.
 * Talep idempotency anahtarıyla açılır: aynı form iki kez gönderilirse
 * ikinci yolculuk oluşmaz.
 */
export default function HailRequestForm({ loggedIn }: { loggedIn: boolean }) {
  const router = useRouter();
  const [form, setForm] = useState({
    pickupDistrict: DISTRICTS[0],
    pickupAddress: "",
    dropDistrict: DISTRICTS[1],
    dropAddress: "",
    distanceKm: 8,
    durationMin: 20,
    serviceType: "standart",
    paymentMethod: "bakiye" as "bakiye" | "fatura",
    note: "",
  });
  const [quote, setQuote] = useState<Quote | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ rideId: number; code: string; status: string } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      const res = await fetch("/api/hail/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ distanceKm: form.distanceKm, durationMin: form.durationMin }),
      });
      if (cancelled || !res.ok) return;
      setQuote((await res.json()) as Quote);
    }, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [form.distanceKm, form.durationMin]);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!loggedIn) {
        router.push("/giris");
        return;
      }
      setBusy(true);
      setError("");
      // Anahtar form içeriğinden türetilir: aynı içerik aynı anahtarı verir.
      const key = idempotencyKey || `hail_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      setIdempotencyKey(key);

      const res = await fetch("/api/hail/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, idempotencyKey: key }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        rideId?: number;
        code?: string;
        status?: string;
        reason?: string;
        error?: string;
      };
      setBusy(false);
      if (!res.ok) {
        setError(data.error ?? "Talep oluşturulamadı.");
        setIdempotencyKey("");
        return;
      }
      setResult({ rideId: data.rideId ?? 0, code: data.code ?? "", status: data.status ?? "" });
      router.refresh();
    },
    [form, idempotencyKey, loggedIn, router],
  );

  if (result) {
    return (
      <div className="rounded-lg border border-accent/35 bg-accent/8 p-6 text-center">
        <p className="text-sm text-slate-300">Talebin alındı</p>
        <p className="mt-2 font-display text-2xl font-bold text-white">{result.code}</p>
        <p className="mt-2 text-sm text-slate-300">
          {result.status === "DRIVER_NO_SHOW"
            ? "Şu an uygun sürücü bulunamadı. Talep kaydedildi; tekrar deneyebilirsin."
            : "Doğrulanmış sürücülere teklif gönderildi. Kabul eden ilk sürücü atanır."}
        </p>
        <Link
          href={`/app/yolculuk/${result.rideId}`}
          className="mt-5 inline-block rounded-md bg-accent px-6 py-3 text-sm font-semibold text-[#0B1220]"
        >
          Yolculuğu takip et
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-5 lg:grid-cols-[1.3fr_0.7fr]">
      <div className="space-y-5">
        <section className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Nereden nereye</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="pickup-district" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                Alım ilçesi
              </label>
              <select
                id="pickup-district"
                value={form.pickupDistrict}
                onChange={(e) => setForm((f) => ({ ...f, pickupDistrict: e.target.value }))}
                className="input-dark mt-2"
              >
                {DISTRICTS.map((d) => (
                  <option key={d} value={d} className="bg-[#0b1220]">
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="drop-district" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                Varış ilçesi
              </label>
              <select
                id="drop-district"
                value={form.dropDistrict}
                onChange={(e) => setForm((f) => ({ ...f, dropDistrict: e.target.value }))}
                className="input-dark mt-2"
              >
                {DISTRICTS.map((d) => (
                  <option key={d} value={d} className="bg-[#0b1220]">
                    {d}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="pickup-address" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                Alım adresi
              </label>
              <input
                id="pickup-address"
                value={form.pickupAddress}
                onChange={(e) => setForm((f) => ({ ...f, pickupAddress: e.target.value }))}
                className="input-dark mt-2"
                placeholder="Mahalle, sokak, bina"
                required
                minLength={10}
              />
            </div>
            <div>
              <label htmlFor="drop-address" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                Varış adresi
              </label>
              <input
                id="drop-address"
                value={form.dropAddress}
                onChange={(e) => setForm((f) => ({ ...f, dropAddress: e.target.value }))}
                className="input-dark mt-2"
                placeholder="Mahalle, sokak, bina"
                required
                minLength={10}
              />
            </div>
          </div>
          <p className="mt-3 text-[11px] text-slate-500">
            Adres yalnızca atanan sürücüye gösterilir; paylaşım bağlantısında ilçe seviyesinde kalır.
          </p>
        </section>

        <section className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Yolculuk</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="distance" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                  Mesafe
                </label>
                <span className="font-display text-sm text-white">{form.distanceKm.toFixed(0)} km</span>
              </div>
              <input
                id="distance"
                type="range"
                min={1}
                max={60}
                value={form.distanceKm}
                onChange={(e) => setForm((f) => ({ ...f, distanceKm: Number(e.target.value) }))}
                className="mt-3 w-full accent-[var(--accent)]"
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="duration" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                  Süre
                </label>
                <span className="font-display text-sm text-white">{form.durationMin} dk</span>
              </div>
              <input
                id="duration"
                type="range"
                min={3}
                max={120}
                value={form.durationMin}
                onChange={(e) => setForm((f) => ({ ...f, durationMin: Number(e.target.value) }))}
                className="mt-3 w-full accent-[var(--accent)]"
              />
            </div>
          </div>
          <fieldset className="mt-5">
            <legend className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Hizmet tipi</legend>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              {SERVICES.map((service) => (
                <button
                  key={service.value}
                  type="button"
                  aria-pressed={form.serviceType === service.value}
                  onClick={() => setForm((f) => ({ ...f, serviceType: service.value }))}
                  className={`min-h-11 rounded-md border px-3 py-2 text-left text-xs transition ${
                    form.serviceType === service.value
                      ? "border-accent bg-accent/12 text-white"
                      : "border-white/12 text-slate-400"
                  }`}
                >
                  <span className="block font-semibold">{service.label}</span>
                  <span className="block text-[10px] opacity-80">{service.note}</span>
                </button>
              ))}
            </div>
          </fieldset>
          <p className="mt-3 text-[11px] text-slate-500">
            Cinsiyet bazlı sürücü/yolcu tercihi sunulmuyor: ayrımcılık mevzuatı açısından riskli ve hukuk onayı yok.
          </p>
        </section>
      </div>

      <aside className="h-fit space-y-4">
        <div className="rounded-lg border border-accent/25 bg-accent/6 p-5">
          <p className="text-[11px] uppercase tracking-[0.14em] text-slate-400">Tahmini ücret</p>
          <p className="mt-2 font-display text-3xl font-bold text-white tabular-nums">
            {quote ? tl(quote.totalKurus) : "—"}
          </p>
          <ul className="mt-4 space-y-1.5 text-xs text-slate-300">
            {(quote?.breakdown ?? []).map((row) => (
              <li key={row.label} className="flex justify-between">
                <span>{row.label}</span>
                <span className="tabular-nums">{row.kurus > 0 ? tl(row.kurus) : ""}</span>
              </li>
            ))}
          </ul>
          {quote?.nightApplied ? <p className="mt-2 text-[11px] text-st-waiting">Gece tarifesi uygulanıyor.</p> : null}
          <p className="mt-3 text-[11px] text-slate-500">{quote?.disclaimer}</p>

          <fieldset className="mt-4">
            <legend className="text-[11px] uppercase tracking-[0.12em] text-slate-400">Ödeme</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {(["bakiye", "fatura"] as const).map((method) => (
                <button
                  key={method}
                  type="button"
                  aria-pressed={form.paymentMethod === method}
                  onClick={() => setForm((f) => ({ ...f, paymentMethod: method }))}
                  className={`min-h-11 rounded-md border px-3 text-xs font-semibold transition ${
                    form.paymentMethod === method ? "border-accent bg-accent/12 text-white" : "border-white/12 text-slate-400"
                  }`}
                >
                  {method === "bakiye" ? "Platform bakiyesi" : "Kurumsal fatura"}
                </button>
              ))}
            </div>
          </fieldset>

          {!quote?.serviceLive ? (
            <p className="mt-4 flex gap-2 rounded-md border border-st-waiting/40 bg-st-waiting/10 p-3 text-[11px] text-slate-300">
              <ShieldAlert size={14} className="mt-0.5 shrink-0 text-st-waiting" aria-hidden />
              <span>
                {quote?.serviceLabel ?? "Pilot"}: akış çalışır ama canlı ticari hizmet olarak sunulmuyor. Talep
                oluşturduğunda gerçek bir sürücü yolcu almaz.
              </span>
            </p>
          ) : null}

          {error ? (
            <p role="alert" className="mt-3 text-sm text-st-risk">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            disabled={busy}
            className="mt-4 w-full rounded-md bg-accent px-5 py-3.5 text-sm font-semibold text-[#0B1220] transition hover:bg-accent-soft disabled:opacity-60"
          >
            {busy ? "Sürücü aranıyor…" : loggedIn ? "Yolculuk talep et" : "Giriş yap ve talep et"}
          </button>
          <p className="mt-2 text-[11px] text-slate-500">
            Talep ödeme doğurabilir: kesin tutar yolculuk sonunda gerçek mesafe ve süreyle hesaplanır.
          </p>
        </div>
      </aside>
    </form>
  );
}
