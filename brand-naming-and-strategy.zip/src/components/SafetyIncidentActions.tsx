"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

/** Güvenlik olayı atama ve çözüm akışı. */
export default function SafetyIncidentActions({
  incidentId,
  status,
  canManage,
}: {
  incidentId: number;
  status: string;
  canManage: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [note, setNote] = useState("");

  if (!canManage) return null;

  async function act(action: "assign" | "resolve" | "close") {
    setBusy(action);
    setError("");
    const res = await fetch(`/api/safety/${incidentId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, resolutionNote: note }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setBusy("");
    if (!res.ok) {
      setError(data.error ?? "İşlem başarısız.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="mt-3 rounded-md bg-slate-50 p-3">
      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Çözüm notu"
        aria-label="Çözüm notu"
        className="input-light py-2 text-sm"
        maxLength={300}
      />
      <div className="mt-2 flex flex-wrap gap-2">
        {status === "open" ? (
          <Action label="Üstlen" onClick={() => act("assign")} busy={busy === "assign"} />
        ) : null}
        {status !== "resolved" && status !== "closed" ? (
          <Action label="Çözüldü" onClick={() => act("resolve")} busy={busy === "resolve"} />
        ) : null}
        {status === "resolved" ? (
          <Action label="Kapat" onClick={() => act("close")} busy={busy === "close"} />
        ) : null}
      </div>
      {error ? <p className="mt-2 text-[11px] text-st-risk">{error}</p> : null}
    </div>
  );
}

function Action({ label, onClick, busy }: { label: string; onClick: () => void; busy: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy}
      className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:border-slate-500 disabled:opacity-60"
    >
      {busy ? "…" : label}
    </button>
  );
}
